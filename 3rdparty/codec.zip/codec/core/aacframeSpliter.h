class AACFrameSpliter
{
    static const int AP4_SUCCESS = 0;
    static const int AP4_FAILURE = -1;
    class AdtsHeader {
    public:
        // constructor
        AdtsHeader(const uint8_t* bytes)
        {
            // fixed part
            m_Id                     = ( bytes[1] & 0x08) >> 3;
            m_ProtectionAbsent       =   bytes[1] & 0x01;
            m_ProfileObjectType      = ( bytes[2] & 0xC0) >> 6;
            m_SamplingFrequencyIndex = ( bytes[2] & 0x3C) >> 2;
            m_ChannelConfiguration   = ((bytes[2] & 0x01) << 2) |
                    ((bytes[3] & 0xC0) >> 6);
            // variable part
            m_FrameLength = ((unsigned int)(bytes[3] & 0x03) << 11) |
                    ((unsigned int)(bytes[4]       ) <<  3) |
                    ((unsigned int)(bytes[5] & 0xE0) >>  5);
            m_RawDataBlocks =               bytes[6] & 0x03;
        }

        // methods
        int Check()
        {
            // check that the sampling frequency index is valid
            if (m_SamplingFrequencyIndex >= 0xD) {
                return AP4_FAILURE;
            }

            /* MPEG2 does not use all profiles */
            if (m_Id == 1 && m_ProfileObjectType == 3) {
                return AP4_FAILURE;
            }

            return AP4_SUCCESS;
        }

        // members

        // fixed part
        unsigned int m_Id;
        unsigned int m_ProtectionAbsent;
        unsigned int m_ProfileObjectType;
        unsigned int m_SamplingFrequencyIndex;
        unsigned int m_ChannelConfiguration;

        // variable part
        unsigned int m_FrameLength;
        unsigned int m_RawDataBlocks;

        // class methods
        static bool MatchFixed(unsigned char* a, unsigned char* b)
        {
            if (a[0]         ==  b[0] &&
                    a[1]         ==  b[1] &&
                    a[2]         ==  b[2] &&
                    (a[3] & 0xF0) == (b[3] & 0xF0)) {
                return true;
            } else {
                return false;
            }
        }
    };
    static const int ADTS_HEADER_SIZE = 7;
    static const int  ADTS_SYNC_MASK =    0xFFF6; /* 12 sync bits plus 2 layer bits */
    static const int ADTS_SYNC_PATTERN = 0xFFF0; /* 12 sync bits=1 layer=0         */
    uint32_t GetSamplingFrequency(uint32_t idx)
    {
        switch (idx) {
        case 0: return 96000;
        case 1: return 88200;
        case 2: return 64000;
        case 3: return 48000;
        case 4: return 44100;
        case 5: return 32000;
        case 6: return 24000;
        case 7: return 22050;
        case 8: return 16000;
        case 9: return 12000;
        case 10: return 11025;
        case 11: return 8000;
        case 12: return 7350;
        default:    return 0;
        }
    }
public:
    struct AACS
    {
        uint32_t offset;
        uint32_t len;
        double duration; // ms
    };

    std::vector<AACS> operator()(uint8_t* p, uint32_t size)
    {
        std::vector<AACS> as;
        if (size < ADTS_HEADER_SIZE)
            return as;
        uint32_t cnt = 0;
        uint8_t* tmp = p;
        while(tmp + ADTS_HEADER_SIZE < p+size)
        {
            uint8_t* header = tmp;
            if ((((header[0] << 8) | header[1]) & ADTS_SYNC_MASK) != ADTS_SYNC_PATTERN)
            {   break; }
            AdtsHeader adts_h(tmp);
            if (adts_h.Check() == -1)
            {
                break;
            }
            AACS a;
            a.offset = tmp-p;
            a.len = adts_h.m_FrameLength;
//            a.duration = 1000.0/adts_h.m_SamplingFrequencyIndex;
            a.duration = 1000.0/GetSamplingFrequency(adts_h.m_SamplingFrequencyIndex)*1024;

            as.push_back(a);
            tmp += adts_h.m_FrameLength;
            ++cnt;
        }
        return as;
    }
};
