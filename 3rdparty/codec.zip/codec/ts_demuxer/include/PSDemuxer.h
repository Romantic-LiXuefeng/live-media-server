#pragma once

class CPSDemuxer
{
public:
	CPSDemuxer(void);
	~CPSDemuxer(void);
};
