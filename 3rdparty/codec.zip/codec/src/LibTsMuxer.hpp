#ifndef LIBTSMUXER_HPP
#define LIBTSMUXER_HPP

#include "codec.h"
#include "global.h"
#include "TsMuxer.h"
#include "libmpeg_sink.h"
#include "bitstreamfilter.h"
#include <string>

class HlsSink : public muxer_sink
{
public:
    HlsSink();
    ~HlsSink();

public:
    void write(unsigned char *p, unsigned int size);

    void setHandler(TsMuxerHandler handler) { m_handler = handler; }

private:
    TsMuxerHandler m_handler;

};

class LibTsMuxer : public CodecTsMuxer
{
public:
    LibTsMuxer();
    virtual ~LibTsMuxer();

    virtual void initialize(bool is_265, bool is_mp3, bool has_v, bool has_a);

    virtual void setTsHandler(TsMuxerHandler handler);

    // only for 264
    virtual int setAudioSequenceHeader(uint8_t *buf, int size);
    virtual int setVideoSequenceHeader(uint8_t *buf, int size);

    virtual int onAudio(uint8_t *buf, int size, int64_t dts, bool is_aac, bool force_Pat_pmt);
    virtual int onVideo(uint8_t *buf, int size, int64_t dts, int64_t pts, bool is_264, bool force_Pat_pmt);

    virtual void close();

private:
    void audio_muxer(bool force_Pat_pmt, bool force);

private:
    h264_mp4toannexb *m_h264_filter;
    aac_asc2adts *m_aac_filter;
    CTsMuxer *m_hls_muxer;
    HlsSink *m_hls_sink;
    AVRational m_in, m_out;

private:
    int64_t m_audio_dts;
    std::string m_audio_data;
    int m_audio_count;

};

#endif // LIBTSMUXER_HPP
