#ifndef LIBVIDEOCODECPRIVATE_HPP
#define LIBVIDEOCODECPRIVATE_HPP

#include <stdint.h>

class LibVideoCodecPrivate
{
public:
    LibVideoCodecPrivate();
    ~LibVideoCodecPrivate();

    /**
    * @brief 函数对象
    * @param buf 数据区
    * @param size　数据区大小
    * @param h264　true表明264；false表明265
    * @return 若有更改返回true;无更改返回false
    * @note 仅处理nal单元小于102400的数据。对于超过1024nal的数据，其行为是未知的．
    * 对象构造后，其pps,sps为空，因此第一次碰到nal被认为是有更改。请注意处理．
    */
    bool sps_pps_changed(uint8_t *buf, uint32_t size, bool h264 = false);

private:
    uint8_t _pps[1024];
    uint8_t _sps[1024];
    int SIZE;
};

#endif // LIBVIDEOCODECPRIVATE_HPP
