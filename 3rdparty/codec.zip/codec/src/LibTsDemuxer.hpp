#ifndef LIBTSDEMUXER_HPP
#define LIBTSDEMUXER_HPP

#include "global.h"
#include "codec.h"
#include "ITSDemuxer.h"
#include "rational.h"
#include "TsMuxer.h"
#include "LibVideoCodecPrivate.hpp"

#include <vector>

typedef struct TsPidType
{
    uint16_t pid;
    //aac=0xf, mp3=0x03, avc=0x1B, hevc=0x24
    uint8_t type;
}TsPidType;

class LibTsDemuxer : public CodecTsDemuxer
{
public:
    LibTsDemuxer();
    virtual ~LibTsDemuxer();

    /**
     * @brief initialize
     * @param size 188,192,204,208
     */
    virtual void initialize(int size);

    /**
     * @brief demuxer
     * @param buf 大小要和构造函数中传入的一致
     * @return
     */
    virtual int demuxer(char *buf);

    virtual void setHandler(TsDemuxerHandler handler);

private:
    bool get_pid();
    uint8_t get_stream_type(uint16_t pid);
    uint8_t get_codec_type(uint16_t pid);
    int aac_spliter(wzd::Packet &pkt);
    int convert_aac(uint8_t *pbuf, uint32_t len, int64_t dts, uint16_t pid);
    int convert_avc(wzd::Packet &pkt);
    int convert_hevc(wzd::Packet &pkt);
    int convert_mp3(wzd::Packet &pkt);

private:
    wzd::ITSDemuxer *m_demuxer;
    AVRational m_in, m_out;

    bool m_inited;
    int m_size;

    std::vector<TsPidType> m_pid_types;

    TsDemuxerHandler m_handler;

    bool m_aac_inited;
    LibVideoCodecPrivate *m_vcodec;
};

#endif // LIBTSDEMUXER_HPP
