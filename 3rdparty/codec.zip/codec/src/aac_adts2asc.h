#ifndef AAC_ADTS2ASC_H
#define AAC_ADTS2ASC_H

#include <stdint.h>

class aac_adts2asc
{
    uint8_t _dsi[2];
    class AdtsHeader {
        static const int AP4_SUCCESS = 0;
        static const int AP4_FAILURE = -1;
    public:
        // constructor
        AdtsHeader(const uint8_t* bytes)
        {
            // fixed part
            m_Id                     = ( bytes[1] & 0x08) >> 3;
            m_ProtectionAbsent       =   bytes[1] & 0x01;
            m_ProfileObjectType      = ( bytes[2] & 0xC0) >> 6;
            m_SamplingFrequencyIndex = ( bytes[2] & 0x3C) >> 2;
            m_ChannelConfiguration   = ((bytes[2] & 0x01) << 2) |
                    ((bytes[3] & 0xC0) >> 6);
            // variable part
            m_FrameLength = ((unsigned int)(bytes[3] & 0x03) << 11) |
                    ((unsigned int)(bytes[4]       ) <<  3) |
                    ((unsigned int)(bytes[5] & 0xE0) >>  5);
            m_RawDataBlocks =               bytes[6] & 0x03;
        }

        // methods
        int Check()
        {
            // check that the sampling frequency index is valid
            if (m_SamplingFrequencyIndex >= 0xD) {
                return AP4_FAILURE;
            }

            /* MPEG2 does not use all profiles */
            if (m_Id == 1 && m_ProfileObjectType == 3) {
                return AP4_FAILURE;
            }

            return AP4_SUCCESS;
        }

        // members

        // fixed part
        unsigned int m_Id;
        unsigned int m_ProtectionAbsent;
        unsigned int m_ProfileObjectType;
        unsigned int m_SamplingFrequencyIndex;
        unsigned int m_ChannelConfiguration;

        // variable part
        unsigned int m_FrameLength;
        unsigned int m_RawDataBlocks;

        // class methods
        static bool MatchFixed(unsigned char* a, unsigned char* b)
        {
            if (a[0]         ==  b[0] &&
                    a[1]         ==  b[1] &&
                    a[2]         ==  b[2] &&
                    (a[3] & 0xF0) == (b[3] & 0xF0)) {
                return true;
            } else {
                return false;
            }
        }
    };
    void genDsi(AdtsHeader& h)
    {
        uint32_t object_type = 2;
        uint32_t nIndex = h.m_SamplingFrequencyIndex;
        _dsi[0] = (object_type << 3) | (nIndex >> 1);
        _dsi[1] = uint8_t(((nIndex & 1) << 7) | (h.m_ChannelConfiguration << 3));
    }
public:
    aac_adts2asc()
    {
        memset(_dsi, 0, sizeof(_dsi));
    }
    /**
     * @brief process
     * @param[in] buf　adts数据
     * @param[in] size　adts数据大小．
     * @param[out] offset asc数据偏移
     * @return 0, success; -1 need more data
     */
    int process(uint8_t* buf, uint32_t size, uint32_t& offset)
    {
        static int const adts_header_size = 7;
        if (size < adts_header_size || buf[0] != 0xff)
            return -1;
        AdtsHeader a(buf);
        genDsi(a);
        offset = adts_header_size;
        return 0;
    }
    /**
     * @brief 获取DSI信息．
     * @param[out] out
     * @param[in out] size
     * @return 0,success; -1,not enougth memory;-2, not init
     */
    int32_t getDsi(uint8_t* out, uint32_t& size)
    {

        if (NULL == out || size < sizeof(_dsi))
        {
            size = sizeof(_dsi);
            return -1;
        }
        if (0 == _dsi[0])
            return -2;
        memcpy(out, _dsi, sizeof(_dsi));
        size = sizeof(_dsi);
        return 0;
    }
};

#endif // AAC_ADTS2ASC_H
