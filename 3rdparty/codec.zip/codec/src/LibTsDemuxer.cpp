#include "LibTsDemuxer.hpp"
#include "aacframeSpliter.h"
#include "aac_adts2asc.h"
#include "bitstreamfilter.h"

using namespace wzd;

CodecTsDemuxer *GetCodecTsDemuxer()
{
    return (new LibTsDemuxer());
}

LibTsDemuxer::LibTsDemuxer()
    : m_inited(false)
    , m_size(188)
    , m_handler(NULL)
    , m_aac_inited(false)
{
    m_demuxer = CreateTSDemuxer(m_size, NULL);

    m_vcodec = new LibVideoCodecPrivate();

    m_in.num = 1;
    m_in.den = 90000;
    m_out.num = 1;
    m_out.den = 1000;
}

LibTsDemuxer::~LibTsDemuxer()
{
    DeleteTSDemuxer(m_demuxer);
    LibFree(m_vcodec);
}

void LibTsDemuxer::initialize(int size)
{
    m_size = size;
}

int LibTsDemuxer::demuxer(char *buf)
{
    int ret = 0;
    const unsigned char* _buf = (const unsigned char*)buf;
    Packet pkt;
    bool is_ok = false;

    if (!m_inited) {
        try {
            int res = m_demuxer->Init(_buf, m_size);
            if (res == 0) {
                m_inited = true;
                get_pid();
            }
        } catch (IException &e) {
            return -1;
        }
    }

    if (m_inited) {
        try {
            int res = m_demuxer->GetESPacket(0, pkt, _buf, m_size);
            if (res == 0) {
                is_ok = true;
            }
        } catch (IException &e) {
            return -2;
        }
    }

    if (is_ok) {
        uint8_t codec = get_codec_type(pkt.pid);
        uint8_t type = get_stream_type(pkt.pid);

        if (type == LibCodecStreamType::Audio) {
            if (codec == LibCodecAVType::AAC) {
                ret = aac_spliter(pkt);
            } else if (codec == LibCodecAVType::MP3) {
                ret = convert_mp3(pkt);
            }
        } else if (type == LibCodecStreamType::Video) {
            if (codec == LibCodecAVType::AVC) {
                ret = convert_avc(pkt);
            } else if (codec == LibCodecAVType::HEVC) {
                ret = convert_hevc(pkt);
            }
        }

        m_demuxer->RecyclePacket(pkt);
    }

    return ret;
}

void LibTsDemuxer::setHandler(TsDemuxerHandler handler)
{
    m_handler = handler;
}

bool LibTsDemuxer::get_pid()
{
    const std::vector<ProgramMapSection> pmts = m_demuxer->GetPmt();

    for (int i = 0; i < pmts.size(); ++i) {
        ProgramMapSection pmt = pmts.at(i);
        for (int j = 0; j < pmt.esInfo.size(); ++j) {
            TsPidType pt;
            pt.pid = pmt.esInfo.at(j).elementary_PID;
            pt.type = pmt.esInfo.at(j).stream_type;

            m_pid_types.push_back(pt);
        }
    }

    if (m_pid_types.empty()) {
        return false;
    }

    return true;
}

uint8_t LibTsDemuxer::get_stream_type(uint16_t pid)
{
    uint8_t ret = LibCodecStreamType::Other;

    for (int i = 0; i < m_pid_types.size(); ++i) {
        TsPidType pt = m_pid_types.at(i);
        if (pid == pt.pid) {
            if (pt.type == 0xf || pt.type == 0x03) {
                ret = LibCodecStreamType::Audio;
                break;
            } else if (pt.type == 0x24 || pt.type == 0x1B) {
                ret = LibCodecStreamType::Video;
                break;
            }
        }
    }

    return ret;
}

uint8_t LibTsDemuxer::get_codec_type(uint16_t pid)
{
    uint8_t ret = -1;

    //aac=0xf, mp3=0x03, avc=0x1B, hevc=0x24
    for (int i = 0; i < m_pid_types.size(); ++i) {
        TsPidType pt = m_pid_types.at(i);
        if (pid == pt.pid) {
            switch (pt.type) {
            case 0xf:
                ret = LibCodecAVType::AAC;
                break;
            case 0x03:
                ret = LibCodecAVType::MP3;
                break;
            case 0x1B:
                ret = LibCodecAVType::AVC;
                break;
            case 0x24:
                ret = LibCodecAVType::HEVC;
                break;
            default:
                break;
            }

            if (ret != -1) {
                return ret;
            }
        }
    }

    return ret;
}

int LibTsDemuxer::aac_spliter(Packet &pkt)
{
    calc_timestamp c(m_in, m_out);
    int64_t timestamp = c.calc(pkt.dts);

    AACFrameSpliter spliter;
    std::vector<AACFrameSpliter::AACS> aacs = spliter(pkt.pbuf, pkt.len);

    for (int i = 0; i < aacs.size(); ++i) {
        AACFrameSpliter::AACS aac = aacs.at(i);

        uint8_t *buf = new uint8_t[aac.len];

        memcpy(buf, pkt.pbuf + aac.offset, aac.len);

        timestamp += aac.duration;

        if (convert_aac(buf, aac.len, timestamp, pkt.pid) != 0) {
            LibFreeArray(buf);
            return -1;
        }

        LibFreeArray(buf);
    }

    return 0;
}

int LibTsDemuxer::convert_aac(uint8_t *pbuf, uint32_t len, int64_t dts, uint16_t pid)
{
    uint32_t offset = 0;
    aac_adts2asc aac_convert;

    if (aac_convert.process(pbuf, len, offset) < 0) {
        return -1;
    }

    if (!m_aac_inited) {
        uint8_t s_buf[2];
        uint32_t s_len = 2;
        if (aac_convert.getDsi(s_buf, s_len) != 0) {
            return -2;
        }

        TsDemuxerPacket s_pkt;
        s_pkt.sequence_header = true;
        s_pkt.keyframe = false;
        s_pkt.dts = 0;
        s_pkt.pts = 0;
        s_pkt.codec = (LibCodecAVType::AVCodecType)get_codec_type(pid);
        s_pkt.type = (LibCodecStreamType::StreamType)get_stream_type(pid);
        s_pkt.buf = s_buf;
        s_pkt.len = 2;

        if (m_handler) {
            if (m_handler(s_pkt) != 0) {
                return -3;
            }
        }

        m_aac_inited = true;
    }

    int size = len - offset;
    uint8_t *payload = new uint8_t[size];
    memcpy(payload, pbuf + offset, size);

    TsDemuxerPacket packet;
    packet.sequence_header = false;
    packet.keyframe = false;
    packet.dts = dts;
    packet.pts = dts;
    packet.codec = (LibCodecAVType::AVCodecType)get_codec_type(pid);
    packet.type = (LibCodecStreamType::StreamType)get_stream_type(pid);
    packet.buf = payload;
    packet.len = size;

    if (m_handler) {
        if (m_handler(packet) != 0) {
            LibFreeArray(payload);
            return -4;
        }
    }

    LibFreeArray(payload);

    return 0;
}

int LibTsDemuxer::convert_avc(Packet &pkt)
{
    calc_timestamp c(m_in, m_out);
    int64_t dts = c.calc(pkt.dts);
    int64_t pts = c.calc(pkt.pts);

    h264_annexbtomp4 h264_convert;
    uint8_t *buf = NULL;
    uint32_t size = 0;

    h264_convert.process(pkt.pbuf, pkt.len, buf, size);

    if (m_vcodec->sps_pps_changed(pkt.pbuf, pkt.len, true)) {
        uint8_t *s_buf = NULL;
        uint32_t s_size = 0;
        h264_convert.getAvcDecodeConfigRecord(s_buf, s_size);

        if (s_buf) {
            TsDemuxerPacket s_pkt;
            s_pkt.sequence_header = true;
            s_pkt.keyframe = true;
            s_pkt.dts = 0;
            s_pkt.pts = 0;
            s_pkt.codec = (LibCodecAVType::AVCodecType)get_codec_type(pkt.pid);
            s_pkt.type = (LibCodecStreamType::StreamType)get_stream_type(pkt.pid);
            s_pkt.buf = s_buf;
            s_pkt.len = s_size;

            if (m_handler) {
                if (m_handler(s_pkt) != 0) {
                    h264_convert.recycle(buf);
                    return -1;
                }
            }
        }
    }

    TsDemuxerPacket packet;
    packet.sequence_header = false;
    packet.dts = dts;
    packet.pts = pts;
    packet.codec = (LibCodecAVType::AVCodecType)get_codec_type(pkt.pid);
    packet.type = (LibCodecStreamType::StreamType)get_stream_type(pkt.pid);
    packet.buf = buf;
    packet.len = size;

    packet.keyframe = false;
    if (video_is_IDR(pkt.pbuf, pkt.len, true)) {
        packet.keyframe = true;
    }

    if (m_handler) {
        if (m_handler(packet) != 0) {
            h264_convert.recycle(buf);
            return -2;
        }
    }

    h264_convert.recycle(buf);

    return 0;
}

int LibTsDemuxer::convert_hevc(Packet &pkt)
{
    calc_timestamp c(m_in, m_out);
    int64_t dts = c.calc(pkt.dts);
    int64_t pts = c.calc(pkt.pts);

    TsDemuxerPacket packet;
    packet.sequence_header = false;
    packet.dts = dts;
    packet.pts = pts;
    packet.codec = (LibCodecAVType::AVCodecType)get_codec_type(pkt.pid);
    packet.type = (LibCodecStreamType::StreamType)get_stream_type(pkt.pid);
    packet.buf = pkt.pbuf;
    packet.len = pkt.len;

    packet.keyframe = false;
    if (video_is_IDR(pkt.pbuf, pkt.len, false)) {
        packet.keyframe = true;
    }

    if (m_handler) {
        if (m_handler(packet) != 0) {
            return -1;
        }
    }

    return 0;
}

int LibTsDemuxer::convert_mp3(Packet &pkt)
{
    calc_timestamp c(m_in, m_out);
    int64_t dts = c.calc(pkt.dts);

    TsDemuxerPacket packet;
    packet.sequence_header = false;
    packet.keyframe = false;
    packet.dts = dts;
    packet.pts = dts;
    packet.codec = (LibCodecAVType::AVCodecType)get_codec_type(pkt.pid);
    packet.type = (LibCodecStreamType::StreamType)get_stream_type(pkt.pid);
    packet.buf = pkt.pbuf;
    packet.len = pkt.len;

    if (m_handler) {
        if (m_handler(packet) != 0) {
            return -1;
        }
    }

    return 0;
}
