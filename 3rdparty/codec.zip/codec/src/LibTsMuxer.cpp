#include "LibTsMuxer.hpp"

CodecTsMuxer *GetCodecTsMuxer()
{
    return (new LibTsMuxer());
}

HlsSink::HlsSink()
    : muxer_sink()
    , m_handler(NULL)
{

}

HlsSink::~HlsSink()
{

}

void HlsSink::write(unsigned char *p, unsigned int size)
{
    if (m_handler) {
        m_handler(p, size);
    }
}

/****************************************************************/

LibTsMuxer::LibTsMuxer()
    : m_h264_filter(NULL)
    , m_aac_filter(NULL)
    , m_hls_muxer(NULL)
    , m_audio_count(0)
{
    m_hls_sink = new HlsSink();

    m_in.num = 1;
    m_in.den = 1000;
    m_out.num = 1;
    m_out.den = 90000;
}

LibTsMuxer::~LibTsMuxer()
{
    LibFree(m_h264_filter);
    LibFree(m_aac_filter);
    LibFree(m_hls_sink);
    LibFree(m_hls_muxer);
}

void LibTsMuxer::initialize(bool is_265, bool is_mp3, bool has_v, bool has_a)
{
    if (m_hls_muxer) {
        m_hls_muxer->InternalClose();
        LibFree(m_hls_muxer);
    }

    m_hls_muxer = new CTsMuxer(is_mp3, is_265);
    m_hls_muxer->InternalOpen(m_hls_sink, has_v, has_a);
}

void LibTsMuxer::setTsHandler(TsMuxerHandler handler)
{
    m_hls_sink->setHandler(handler);
}

int LibTsMuxer::setAudioSequenceHeader(uint8_t *buf, int size)
{
    LibFree(m_aac_filter);

    try {
        m_aac_filter = new aac_asc2adts(buf, size);
    } catch (std::exception &e) {
        LibFree(m_aac_filter);
        return -1;
    }

    return 0;
}

int LibTsMuxer::setVideoSequenceHeader(uint8_t *buf, int size)
{
    LibFree(m_h264_filter);
    m_h264_filter = new h264_mp4toannexb(buf, size);

    return 0;
}

int LibTsMuxer::onAudio(uint8_t *buf, int size, int64_t dts, bool is_aac, bool force_Pat_pmt)
{
    uint8_t *pout = NULL;
    size_t poutbufsize;

    if (m_aac_filter && is_aac) {
        m_aac_filter->aac_asc2adts_filter(buf, size, &pout, &poutbufsize);
    } else {
        pout = buf;
        poutbufsize = size;
    }

    if (pout && poutbufsize != 0) {
        if (m_audio_count == 0) {
            m_audio_dts = dts;
        }

        m_audio_data.append((char*)pout, poutbufsize);
        m_audio_count++;

		if (force_Pat_pmt) {
			audio_muxer(true, true);
		} else {
        	audio_muxer(false, false);
		}

        if (m_aac_filter) {
            m_aac_filter->recycle(&pout);
        }
    }

    return 0;
}

int LibTsMuxer::onVideo(uint8_t *buf, int size, int64_t dts, int64_t pts, bool is_264, bool force_Pat_pmt)
{
    audio_muxer(false, true);

    unsigned char* pout = NULL;
    int poutbufsize;

    if (m_h264_filter && is_264) {
        if (m_h264_filter->h264_mp4toannexb_filter(&pout, &poutbufsize, buf, size) != 1) {
            return -1;
        }
    } else {
        pout = buf;
        poutbufsize = size;
    }

    if (pout && poutbufsize != 0) {
        IMediaFrame *frame = new IMediaFrame;
        LibAutoFree(IMediaFrame, frame);

        calc_timestamp c(m_in, m_out);
        frame->strmID = 0;
        frame->info.dts = c.calc(dts);
        frame->info.pts = c.calc(pts);
        frame->lpdata = pout;
        frame->dwSize = poutbufsize;

        m_hls_muxer->OnWriteFrame(frame, force_Pat_pmt);
        m_hls_muxer->flush();

        if (m_h264_filter) {
            m_h264_filter->recycle(&pout);
        }
    }

    return 0;
}

void LibTsMuxer::close()
{
    audio_muxer(false, true);

    m_hls_muxer->flush();
    m_hls_muxer->InternalClose();

    LibFree(m_aac_filter);
    LibFree(m_h264_filter);
    LibFree(m_hls_muxer);
}

void LibTsMuxer::audio_muxer(bool force_Pat_pmt, bool force)
{
    if (m_audio_data.empty()) {
        return;
    }

    if (!force && m_audio_count < 7) {
        return;
    }

    IMediaFrame *frame = new IMediaFrame;
    LibAutoFree(IMediaFrame, frame);

    calc_timestamp c(m_in, m_out);
    frame->strmID = 10;
    frame->info.dts = c.calc(m_audio_dts);
    frame->info.pts = c.calc(m_audio_dts);

    frame->lpdata = (unsigned char*)m_audio_data.data();
    frame->dwSize = m_audio_data.size();

    m_hls_muxer->OnWriteFrame(frame, force_Pat_pmt);
    m_hls_muxer->flush();

    m_audio_data.clear();
    m_audio_count = 0;
}
