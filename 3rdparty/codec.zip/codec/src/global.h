#ifndef GLOBAL_H
#define GLOBAL_H

#include <stdio.h>

#define LibFree(ptr) \
    do { if (ptr) { delete ptr; ptr = NULL;} } while (0)

#define LibFreeArray(ptr) \
    do { if (ptr) { delete [] ptr; ptr = NULL;} } while (0)

#define LibAutoFree(className, instance) \
impl__LibAutoFree<className> _auto_free_##instance(&instance, false)

template<class T>
class impl__LibAutoFree
{
private:
    T** ptr;
    bool is_array;
public:
    /**
     * auto delete the ptr.
     */
    impl__LibAutoFree(T** p, bool array) {
        ptr = p;
        is_array = array;
    }

    virtual ~impl__LibAutoFree() {
        if (ptr == NULL || *ptr == NULL) {
            return;
        }

        if (is_array) {
            delete[] *ptr;
        } else {
            delete *ptr;
        }

        *ptr = NULL;
    }
};

#endif // GLOBAL_H
