#include "LibVideoCodecPrivate.hpp"
#include <string.h>

LibVideoCodecPrivate::LibVideoCodecPrivate()
{
    SIZE = 1024;
    memset(_pps, 0, sizeof(_pps));
    memset(_sps, 0, sizeof(_sps));
}

LibVideoCodecPrivate::~LibVideoCodecPrivate()
{

}

bool LibVideoCodecPrivate::sps_pps_changed(uint8_t *buf, uint32_t size, bool h264)
{
    if (size < 4)
        return false; // 无pps,sps
    static int const PPS_NUT = 34;
    static int const SPS_NUT = 33;
    static int const PPS = 8;
    static int const SPS = 7;
    // 切分nal
    uint8_t* nals[1024];
    uint32_t idx = 0;
    int x = sizeof(nals);
    memset(nals, 0, sizeof(nals));
    for (uint32_t i = 2; i < size ; ++i)
    {
        if (0x01 == buf[i] && 0x00 == buf[i-1] && 0x00 == buf[i-2])
        {
            nals[idx++] = buf+i;
        }
    }
    // 比较/更新pps,sps
    bool change = false;
    for (int i = 0; i < idx; ++i)
    {
        uint8_t nal_type = 0;
        uint8_t* p = nals[i];
        uint8_t* s = NULL;
        if(nals[i]+1 >= buf+size)
            break; // 防止越界
        if (false == h264)
        {
            nal_type = nals[i][1] >> 1 & 0x3F;
            if (nal_type == PPS_NUT)
            {
                s = _pps;
            }else if (nal_type == SPS_NUT)
            {
                s = _sps;
            }
        }
        else
        {
            nal_type = nals[i][1] & 0x1f;
            if (PPS == nal_type)
            {
                s = _pps;
            } else if (SPS == nal_type)
            {
                s = _sps;
            }
        }
        if (NULL == s)
            continue; //非PPS/SPS
        uint32_t nal_size = (i+1 == idx? buf+size-nals[i]: nals[i+1]-nals[i]);
        uint32_t size = nal_size <= SIZE?nal_size:SIZE;
        for(int j = 0; j < size; ++j)
        {
            if (s[j] != p[j])
                change = true;
            s[j] = p[j];
        }
    }
    return change;
}

/*************************************************/

bool video_is_IDR(uint8_t *buf, uint32_t size, bool h264 = false)
{
    if (size < 4)
        return false;

    static int const BLA_W_LP = 16;
    static int const RSV_IRAP_VCL23 = 23;
    static int const SLICE_IDR_PICTURE = 5;

    for (uint32_t i = 2; i < size ; ++i)
    {
        if (0x01 == buf[i] && 0x00 == buf[i-1] && 0x00 == buf[i-2])
        {
            if (buf+i == buf+size-1) // end
                return false;

            if (false == h264)
            {
                uint8_t nal_type = buf[i+1] >> 1 & 0x3F;
                if (nal_type >= BLA_W_LP && nal_type <= RSV_IRAP_VCL23)
                {
                    return true;
                }
            }
            else
            {
                uint8_t nal_type = buf[i+1] & 0x1f;
                if (nal_type == SLICE_IDR_PICTURE)
                    return true;

            }
        }
    }
    return false;
}
