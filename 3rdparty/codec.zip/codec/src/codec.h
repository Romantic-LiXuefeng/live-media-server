#ifndef LIBCODEC_H
#define LIBCODEC_H

#include <tr1/functional>
#include <stdint.h>

#define DLL_PUBLIC __attribute__ ((visibility("default")))

typedef std::tr1::function<int (unsigned char *p, unsigned int size)> TsMuxerHandler;
#define TS_MUXER_CALLBACK(str)  std::tr1::bind(str, this, std::tr1::placeholders::_1, std::tr1::placeholders::_2)

class CodecTsMuxer
{
public:
    virtual ~CodecTsMuxer() {}

    virtual void initialize(bool is_265, bool is_mp3, bool has_v, bool has_a) = 0;

    virtual void setTsHandler(TsMuxerHandler handler) = 0;

    // only for aac
    virtual int setAudioSequenceHeader(uint8_t *buf, int size) = 0;
    // only for 264
    virtual int setVideoSequenceHeader(uint8_t *buf, int size) = 0;

    virtual int onAudio(uint8_t *buf, int size, int64_t dts, bool is_aac, bool force_Pat_pmt) = 0;
    virtual int onVideo(uint8_t *buf, int size, int64_t dts, int64_t pts, bool is_264, bool force_Pat_pmt) = 0;

    virtual void close() = 0;

};

DLL_PUBLIC CodecTsMuxer *GetCodecTsMuxer();

/************************ ts demuxer ***************************/

namespace LibCodecAVType
{
    enum AVCodecType { AN = 0, AAC, MP3, VN, AVC, HEVC };
}

namespace LibCodecStreamType
{
    enum StreamType { Audio = 0, Video, Other };
}

typedef struct TsDemuxerPacket
{
    int64_t pts;
    int64_t dts;
    LibCodecAVType::AVCodecType codec;
    LibCodecStreamType::StreamType type;
    uint8_t *buf;
    uint32_t len;
    bool sequence_header;
    bool keyframe;
}TsDemuxerPacket;

typedef std::tr1::function<int (TsDemuxerPacket pkt)> TsDemuxerHandler;
#define TS_DEMUXER_CALLBACK(str)  std::tr1::bind(str, this, std::tr1::placeholders::_1)

class CodecTsDemuxer
{
public:
    virtual ~CodecTsDemuxer() {}
    virtual void initialize(int size) = 0;
    virtual int demuxer(char *buf) = 0;
    virtual void setHandler(TsDemuxerHandler handler) = 0;
};

DLL_PUBLIC CodecTsDemuxer *GetCodecTsDemuxer();

/**
 * @brief 判断这一帧数据是否为Ｉ帧
 * @param[in] buf　数据区指针
 * @param[in] size　数据区大小
 * @param[in] h264　true表明是H264,false表明是H265
 * @return true表明包含Ｉ帧，false表明不包含
 */
DLL_PUBLIC bool video_is_IDR(uint8_t *buf, uint32_t size, bool h264 = false);

#endif // LIBCODEC_H
