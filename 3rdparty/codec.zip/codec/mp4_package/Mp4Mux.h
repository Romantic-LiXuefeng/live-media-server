/////////////////////////////////////////////////////////////////////////////////////////////
// Project:Mp4Format
// Author:ChenZhong
// Description:The Mp4 Muxer of Dom Frame,Current Only for Video(h.264) and Audio(aac)
/////////////////////////////////////////////////////////////////////////////////////////////
#ifndef __MP4MUX_H__
#define __MP4MUX_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <stdint.h>

#include "Mp4BoxDefine.h"
#include "libmpeg_sink.h"
#pragma pack(push,1)
typedef struct _PAYLOADINFO
{
	DWORD dwIndex;
	BOOL bIsKeyFrame;
	LONGLONG llPts;
	LONGLONG llDts;
	DWORD dwOffset;
	DWORD dwSize;
    _PAYLOADINFO()
    {
        dwIndex = 0;
        bIsKeyFrame = false;
        llPts = llDts = 0;
        dwOffset = 0;
        dwSize = 0;
    }
    bool operator !=(_PAYLOADINFO& p)
    {
        return p.bIsKeyFrame != this->bIsKeyFrame
                || p.dwIndex != this->dwIndex
                ||  p.llDts != this->llDts
                || p.llPts != this->llPts
                || p.dwOffset != this->dwOffset
                ||  p.dwSize != this->dwSize;
    }
}
PAYLOADINFO,*LPPAYLOADINFO;
#pragma pack(pop)

#include <list>
#define VIDEO_STREAM_ID 0
#define AUDIO_STREAM_ID 1
#define MAX_PAYLOAD_SIZE (3 * 1024 * 1024)




#define MMEDIA_FRAME_FLAG_SYNCPOINT 1
#ifndef IMediaFrame_Class
#define IMediaFrame_Class
class IMediaFrame
{
public:

    struct MMEDIA_FRAME_INFO
    {
        LONGLONG pts;
        LONGLONG dts;
        int flag;
    };
    MMEDIA_FRAME_INFO info;
    LPBYTE lpdata;
    DWORD dwSize;
    DWORD strmID; // v:0,A:1
};
#endif

/**
 * 支持单音频／单视频／音视频复用．
 * 音频仅支持aac，视频仅支持264
 */
class CMp4Mux
{
bool m_writeMdatH;
public:
    struct AudioParameter
    {
        bool absent;//是否无音频流．默认为true
        uint32_t bitPreSample;
        uint32_t timebase_den;
        uint32_t timebase_num; // reserved
        AudioParameter()
        {
            absent = true;
            // 这些值的初始化是常见参数，无特殊意义。
            bitPreSample = 16;
            timebase_den = timebase_num = 1;
        }
    };
    struct VideoParameter
    {
        bool absent; //是否无视频流．默认为true
        uint32_t ratioX;
        uint32_t ratioY;
        uint32_t timebase_den;
        uint32_t timebase_num; // reserved
        VideoParameter()
        {
            absent = true;
            //这些值的初始化是常见参数，无特殊意义。
            ratioX = 16;
            ratioY = 9;
            timebase_den = timebase_num = 1;
        }
    };
	//CMp4Mux class declare
	CMp4Mux();
	virtual ~CMp4Mux();

    HRESULT OnWriteFrame(IMediaFrame* pFrame);

    /**
     * @brief 需要获取mdat的长度
     * @return　mdataBox的大小．
     * @warning 只能在internalclose之后调用才有效
     */
    uint32_t GetMdataSize() { return m_dwDataSize + sizeof(MDATBOX); }
    /**
     * @brief InternalOpen
     * @param[in] s　回调接口。
     * @param[in] ap 音频参数
     * @param[in] vp　视频参数
     * @return
     */
    HRESULT InternalOpen(muxer_sink* s, const AudioParameter& ap, const VideoParameter& vp);
    /**
     * @brief InternalClose
     * @param moveMoov　是否将moov移动到mdat前面
     * @return
     */
    HRESULT InternalClose(bool moveMoov = false);

    // avc offset 5, aac offset 2 mp3 offset 1
//    void set_audio_dis(uint32_t id, uint8_t* p, uint_size)
//    {

//    }
//    void set_video_dis(uint32_t id, uint8_t* p, uint_size)
//    {

//    }

protected:
	DWORD WriteFtypBox(DWORD dwCompatibleBrands[],DWORD dwCount);
	HRESULT WriteMdatBox(DWORD dwDataSize = 0);
    int32_t WritePayLoad(LPBYTE lpBuffer,DWORD dwSize,DWORD dwStreamID,LONGLONG llPts,LONGLONG llDts,BOOL isSyncPoint);
private:
	DWORD WriteMoovBox(LPBYTE lpData);
	DWORD WriteMvhdBox(LPBYTE lpData);
	DWORD WriteTrakBox(LPBYTE lpData,DWORD dwTrackID);
	DWORD WriteTkhdBox(LPBYTE lpData,DWORD dwTrackID);
	DWORD WriteEdtsBox(LPBYTE lpData,DWORD dwTrackID);
	DWORD WriteElstBox(LPBYTE lpData,DWORD dwTrackID);
	DWORD WriteMdiaBox(LPBYTE lpData,DWORD dwTrackID);
	DWORD WriteMdhdBox(LPBYTE lpData,DWORD dwTrackID);
	DWORD WriteHdlrBox(LPBYTE lpData,DWORD dwTrackID);
	DWORD WriteMinfBox(LPBYTE lpData,DWORD dwTrackID);
	DWORD WriteVmhdBox(LPBYTE lpData,DWORD dwTrackID);
	DWORD WriteSmhdBox(LPBYTE lpData,DWORD dwTrackID);
	DWORD WriteDinfBox(LPBYTE lpData,DWORD dwTrackID);
	DWORD WriteDrefBox(LPBYTE lpData,DWORD dwTrackID);
	DWORD WriteUrlBox(LPBYTE lpData,LPTSTR lpUrl);
	DWORD WriteStblBox(LPBYTE lpData,DWORD dwTrackID);
	DWORD WriteStsdBox(LPBYTE lpData,DWORD dwTrackID);
	DWORD WriteVisualSampleEntry(LPBYTE lpData,DWORD dwTrackID);
	DWORD WriteAudioSampleEntry(LPBYTE lpData,DWORD dwTrackID);
	DWORD WriteAvcCBox(LPBYTE lpData);
	DWORD WriteEsdsBox(LPBYTE lpData,DWORD dwTrackID);
	DWORD WriteSttsBox(LPBYTE lpData,DWORD dwTrackID);
	DWORD WriteCttsBox(LPBYTE pBuffer,DWORD nTrackID);
	DWORD WriteStssBox(LPBYTE lpData,DWORD dwTrackID);
	DWORD WriteStscBox(LPBYTE lpData,DWORD dwTrackID);
	DWORD WriteStszBox(LPBYTE lpData,DWORD dwTrackID);
	DWORD WriteStcoBox(LPBYTE lpData,DWORD dwTrackID);
private:
	DWORD LE_BE(DWORD dwValue);
	WORD LE_BE(WORD wValue);
	INT64 LE_BE(INT64 nValue);
	BOOL GetBoxSize(LPBYTE lpData,DWORD& dwSize,DWORD& dwNalSize);
	UINT CompuLen(UINT nLen);
	UINT AddDes(LPBYTE lpData, INT nTag, UINT nSize);
	INT GetSamplingFrequencyIndex(UINT nFrequency);
    INT GetSamplingFrequency(UINT idx);
    bool ParseADTSHeader(uint8_t *buf, uint32_t size);
    bool parse_sps(uint8_t* bytes, uint32_t size);
    void Init();
private:
    DWORD m_dwDataSize; // for mdat
	DWORD m_dwDataOffset;
    DWORD m_dwFtypSize;
	DWORD m_dwFileWriteOffset;

    bool m_bHasVideo;
    bool m_bHasAudio;

    int32_t m_nVideoIndex;
    int32_t m_nAudioIndex;
	DWORD m_dwCurrentTick;

	DWORD m_dwMoovSize;
	DWORD m_dwStreamCount;

	//file
	DWORD m_dwTimeScale;
	DWORD m_dwDuration;
	DWORD m_dwVideoDuration;
	DWORD m_dwAudioDuration;
	//video param
	DWORD m_dwWidth;
	DWORD m_dwHeight;
    DWORD m_ratioX;
    DWORD m_ratioY;
	double m_dbFrameRate;
	INT m_nProfile;
	INT m_nProfileCompatibility;
	INT m_nLevel;
    static int const m_nNalSize = 4; //nal 单元大小所占的字节长度。
	DWORD m_dwVideoDsiLen;
    LPBYTE m_lpVideoDsiData; // global header
	LPBYTE m_lpRecovryBuffer;
    double m_vtimebase_den;
	//audio param
    DWORD m_dwChannelCount;
    DWORD m_dwBitsPerSample;
    DWORD m_dwFrequency;
    double m_dbFrequency;
    BYTE m_byAudioDsiData[2]; // global header
    double m_atimebase_den;
	DWORD m_dwVideoSampleCount;
	DWORD m_dwAudioSampleCount;
	std::list<PAYLOADINFO> m_listVideoSampleTable;
	std::list<PAYLOADINFO> m_listAudioSampleTable;

    muxer_sink* m_pStream;

	BOOL m_bAudioFirst;
	BOOL m_bVideoFirst;
	LONGLONG m_llAudioFirst;
    LONGLONG m_llAudioLast; // for debug
	LONGLONG m_llVideoFirst;
    LONGLONG m_llVideoLast; // for debug

};
#endif //__MP4MUX_H__
