/////////////////////////////////////////////////////////////////////////////////////////////
// Project:Mp4Format
// Author:ChenZhong
// Date:������, ���� 17, 2012
// Description:The Mp4 Box Define for Muxer
/////////////////////////////////////////////////////////////////////////////////////////////
#ifndef __MP4BOXDEFINE_H__
#define __MP4BOXDEFINE_H__

#include <Stdafx.h>

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define ATOM_BOX_TYPE(c4,c3,c2,c1)  \
	((((UINT32)c1)<<24) |  \
	(((UINT32)c2)<<16) |  \
	(((UINT32)c3)<< 8) |  \
	(((UINT32)c4)    ))

const UINT32 FILE_BRAND_QT__ = ATOM_BOX_TYPE('q','t',' ',' ');
const UINT32 FILE_BRAND_ISOM = ATOM_BOX_TYPE('i','s','o','m');
const UINT32 FILE_BRAND_ISO1 = ATOM_BOX_TYPE('i','s','o','1');
const UINT32 FILE_BRAND_ISO2 = ATOM_BOX_TYPE('i','s','o','2');
const UINT32 FILE_BRAND_ISO3 = ATOM_BOX_TYPE('i','s','o','3');
const UINT32 FILE_BRAND_ISO4 = ATOM_BOX_TYPE('i','s','o','4');
const UINT32 FILE_BRAND_ISO5 = ATOM_BOX_TYPE('i','s','o','5');
const UINT32 FILE_BRAND_ISO6 = ATOM_BOX_TYPE('i','s','o','6');
const UINT32 FILE_BRAND_MP41 = ATOM_BOX_TYPE('m','p','4','1');
const UINT32 FILE_BRAND_MP42 = ATOM_BOX_TYPE('m','p','4','2');
const UINT32 FILE_BRAND_3GP1 = ATOM_BOX_TYPE('3','g','p','1');
const UINT32 FILE_BRAND_3GP2 = ATOM_BOX_TYPE('3','g','p','2');
const UINT32 FILE_BRAND_3GP3 = ATOM_BOX_TYPE('3','g','p','3');
const UINT32 FILE_BRAND_3GP4 = ATOM_BOX_TYPE('3','g','p','4');
const UINT32 FILE_BRAND_3GP5 = ATOM_BOX_TYPE('3','g','p','5');
const UINT32 FILE_BRAND_3G2A = ATOM_BOX_TYPE('3','g','2','a');
const UINT32 FILE_BRAND_MMP4 = ATOM_BOX_TYPE('m','m','p','4');
const UINT32 FILE_BRAND_M4A_ = ATOM_BOX_TYPE('M','4','A',' ');
const UINT32 FILE_BRAND_M4P_ = ATOM_BOX_TYPE('M','4','P',' ');
const UINT32 FILE_BRAND_MJP2 = ATOM_BOX_TYPE('m','j','p','2');
const UINT32 FILE_BRAND_ODCF = ATOM_BOX_TYPE('o','d','c','f');
const UINT32 FILE_BRAND_OPF2 = ATOM_BOX_TYPE('o','p','f','2');
const UINT32 FILE_BRAND_AVC1 = ATOM_BOX_TYPE('a','v','c','1');

#define SELFBOXSIZE 8

#pragma pack(push,1)

typedef struct _BASEBOX
{
	DWORD dwSize;
	DWORD dwName;
}
BASEBOX,*LPBASEBOX;

typedef struct _FULLBOX : public _BASEBOX
{
	BYTE byVersion;
	BYTE byFlags[3];
}
FULLBOX,*LPFULLBOX;

typedef struct _MDATBOX : public _BASEBOX
{
}
MDATBOX,*LPMDATBOX;

typedef struct _FTYPBOX : public _BASEBOX
{
	DWORD dwMajorBrand;
	DWORD dwMinorVersion;
//	DWORD dwCompatibleBrands[1];
}
FTYPBOX,*LPFTYPBOX;

typedef struct _MOOVBOX : public _BASEBOX
{
}
MOOVBOX,*LPMOOVBOX;

typedef struct _MVHDBOX : public _FULLBOX
{
	DWORD dwCreateTime;
	DWORD dwModifyTime;
	DWORD dwTimeScale;
	DWORD dwDuration;
	DWORD dwPlaySpeed;
	WORD wVolume;
	BYTE byReserved[10];
	DWORD dwMatrix[9];
	DWORD dwPreviewTime;
	DWORD dwPreviewDuration;
	DWORD dwPosterTime;
	DWORD dwSelectionTime;
	DWORD dwSelectionDuration;
	DWORD dwCurrentTime;
	DWORD dwNextTrackID;
}
MVHDBOX,*LPMVHDBOX;

typedef struct _IODSBOX : public _BASEBOX
{
}
IODSBOX,*LPIODSBOX;

typedef struct _TRAKBOX :  public _BASEBOX
{
}
TRAKBOX,*LPTRAKBOX;

typedef struct _TKHDBOX : public _FULLBOX
{
	DWORD dwCreateTime;
	DWORD dwModifyTime;
	DWORD dwTrackID;
	DWORD dwReserved;
	DWORD dwDuration;
	BYTE byResvered[8];
	WORD wLayer;
	WORD wAltemateData;
	WORD wVolume;
	WORD wResvered;
	DWORD dwMatrix[9];
	DWORD dwWidth;
	DWORD dwHeight;	
}
TKHDBOX,*LPTKHDBOX;

typedef struct _EDTSBOX : public _BASEBOX
{

}
EDTSBOX,*LPEDTSBOX;

typedef struct _ELSTBOX : public _FULLBOX
{
	DWORD dwEntryCount;
	DWORD dwDuration;
	DWORD dwMediaTime;
	WORD wInteger;
	WORD wFraction;
}
ELSTBOX,*LPELSTBOX;

typedef struct _MDIABOX : public _BASEBOX
{
}
MDIABOX,*LPMDIABOX;

typedef struct _MDHDBOX : public _FULLBOX
{
	DWORD dwCreateTime;
	DWORD dwModifyTime;
	DWORD dwTimeScale;
	DWORD dwDuration;
	WORD wLanguage;
	WORD wQuality;
}
MDHDBOX,*LPMDHDBOX;

typedef struct _HDLRBOX : public _FULLBOX
{
	//Component
	DWORD dwType;//mhlr,dhlr
	DWORD dwSubType;//mhlr:vide,soun;dhlr:alis;
	DWORD dwManufacturer;
	DWORD dwFlags;
	DWORD dwFlagMask;
}
HDLRBOX,*LPHDLRBOX;

typedef struct _MINFBOX : public _BASEBOX
{
}
MINFBOX,*LPMINFBOX;

typedef struct _VMHDBOX : public _FULLBOX
{
	DWORD dwGraphicsMode;
	DWORD dwOpColor;
}
VMHDBOX,*LPVMHDBOX;

typedef struct _SMHDBOX : public _FULLBOX
{
	WORD wBalance;
	WORD wResvered;
}
SMHDBOX,*LPSMHDBOX;

typedef struct _HMHDBOX : public _BASEBOX
{
	WORD wMaxPduSize;
	WORD wAvgPduSize;
	DWORD dwMaxBitrate;
	DWORD dwAvgBitrate;
	DWORD dwReserved;
}
HMHDBOX,*LPHMHDBOX;

typedef struct _NMHDBOX : public _BASEBOX
{

}
NMHDBOX,*LPNMHDBOX;

typedef struct _DINFBOX : public _BASEBOX
{
}
DINFBOX,*LPDINFBOX;

typedef struct _DREFBOX : public _FULLBOX
{
	DWORD dwEntryCount;//url or urn count
}
DREFBOX,*LPDREFBOX;

typedef struct _URLBOX : public _BASEBOX
{

}
URLBOX,*LPURLBOX;

typedef struct _STBLBOX : public _BASEBOX
{
}
STBLBOX,*LPSTBLBOX;

typedef struct _STSDBOX : public _FULLBOX
{
	DWORD dwSampleDescriptionCount;
//	DWORD dwSampleDescriptionSize;
//	DWORD dwSampleDescriptionFormat;
}
STSDBOX,*LPSTSDBOX;

typedef struct _SAMPLEENTRY : public _BASEBOX
{
	DWORD dwReserved;
	WORD wReserved;
	WORD wDataRefIndex;
}
SAMPLEENTRY,*LPSAMPLEENTRY;

typedef struct _VISUALSAMPLEENTRY : public _SAMPLEENTRY
{
	WORD wPreDefined1;
	WORD wReserved;
	DWORD dwPreDefined[3];
	WORD wWidth;
	WORD wHeight;
	DWORD dwHorizontalResolution;
	DWORD dwVerticalResolution;
	DWORD dwReserved;
	WORD wFrameCount;
	CHAR cCompressName[32];
	WORD wDepth;
	WORD wPreDefined2;
}
VISUALSAMPLEENTRY,*LPVISUALSAMPLEENTRY;

typedef struct _AUDIOSAMPLEENTRY : public _SAMPLEENTRY
{
	DWORD dwReserved[2];
	WORD wChannelCount;
	WORD wSampleSize;
	WORD wPreDefined;
	WORD wReserved;
	DWORD dwSampleRate;
}
AUDIOSAMPLEENTRY,*LPAUDIOSAMPLEENTRY;

typedef struct _AVCCBOX : public _BASEBOX
{

}
AVCCBOX,*LPAVCCBOX;

typedef struct _ESDSBOX : public _FULLBOX
{
	BYTE byData[1];
}
ESDSBOX,*LPESDSBOX;

typedef struct _STTSENTITY
{
	DWORD dwSampleCount;
	DWORD dwSampleDuration;
}
STTSENTITY,*LPSTTSENTITY;

typedef struct _STTSBOX : public _FULLBOX
{
	DWORD dwCount;
	STTSENTITY sEntity[1];
}
STTSBOX,*LPSTTSBOX;

typedef struct _STSSENTITY
{
	DWORD dwKeyFrameNum;
}
STSSENTITY,*LPSTSSENTITY;

typedef struct _STSSBOX : public _FULLBOX
{
	DWORD dwCount;
	STSSENTITY sEntity[1];
}
STSSBOX,*LPSTSSBOX;

typedef struct _STSCENTITY
{
	DWORD dwFirstChunk;
	DWORD dwSamplePerChunk;
	DWORD dwSampleDescriptionID;
}
STSCENTITY,*LPSTSCENTITY;

typedef struct _STSCBOX : public _FULLBOX
{
	DWORD dwCount;
	STSCENTITY sEntity[1];
}
STSCBOX,*LPSTSCBOX;

typedef struct _STSZENTITY
{
	DWORD dwSampleSize;
}
STSZENTITY,*LPSTSZENTITY;

typedef struct _STSZBOX : public _FULLBOX
{
	DWORD dwSampleSize;
	DWORD dwCount;
	STSZENTITY sEntity[1];
}
STSZBOX,*LPSTSZBOX;

typedef struct _STCOENTITY
{
	DWORD dwChunkAddr;
}
STCOENTITY,*LPSTCOENTITY;

typedef struct _STCOBOX : public _FULLBOX
{
	DWORD dwCount;
	STCOENTITY sEntity[1];
}
STCOBOX,*LPSTCOBOX;

typedef struct _CTTSENTITY
{
	DWORD dwSampleCount;
	DWORD dwSampleOffset;
}
CTTSENTITY,*LPCTTSENTITY;

typedef struct _CTTSBOX : public _FULLBOX
{
	DWORD dwCount;
	CTTSENTITY sEntity[1];
}
CTTSBOX,*LPCTTSBOX;

#pragma pack(pop)



#endif //__MP4BOXDEFINE_H__
