/////////////////////////////////////////////////////////////////////////////////////////////
// Project:Mp4Format
// Author:
// Date:������, ���� 17, 2012
// Description:The Mp4 Muxer of Dom Frame,Current Only for Video(h.264) and Audio(aac)
/////////////////////////////////////////////////////////////////////////////////////////////
#include "Stdafx.h"
#include <cassert>
#include "Mp4Mux.h"
#include <stdlib.h>
#include <memory>
//Mp4MuxFormat
CMp4Mux::CMp4Mux()
{
   Init();
}

CMp4Mux::~CMp4Mux()
{
    if(m_lpVideoDsiData)
        delete [] m_lpVideoDsiData;
    if(m_lpRecovryBuffer)
        delete [] m_lpRecovryBuffer;
}


HRESULT CMp4Mux::OnWriteFrame(IMediaFrame* pFrame)
{
    if (!pFrame)
        return E_INVALID_ARG;
    if (pFrame->dwSize == 0
            || pFrame->lpdata == NULL
            || pFrame->info.dts > pFrame->info.pts)
        return E_INVALID_ARG;

    if (false == m_writeMdatH)
    {
        WriteMdatBox(0);
        m_writeMdatH = true;
    }
    DWORD dwStreamID = pFrame->strmID;
    IMediaFrame::MMEDIA_FRAME_INFO info = pFrame->info;

    bool isSyncPoint =  info.flag == MMEDIA_FRAME_FLAG_SYNCPOINT;
    if(-1 == WritePayLoad(pFrame->lpdata,		pFrame->dwSize,dwStreamID,		info.pts,info.dts,isSyncPoint))
        return E_TIMESTAMP;
    return S_OK;
}

HRESULT CMp4Mux::InternalOpen(muxer_sink *s, const AudioParameter &ap, const VideoParameter &vp)
{
    Init();
    m_pStream = s;

    m_lpRecovryBuffer = new BYTE[MAX_PAYLOAD_SIZE];
    if(m_lpRecovryBuffer == NULL) return ERROR_NOT_ENOUGH_MEMORY;

    DWORD dwCompatibleBrand[] =
    {
        FILE_BRAND_ISOM,
        //FILE_BRAND_AVC1,
        FILE_BRAND_MP42
    };
    m_dwFtypSize = WriteFtypBox(dwCompatibleBrand,sizeof(dwCompatibleBrand)/sizeof(DWORD));

    if (false == vp.absent)
    {
        m_bHasVideo = true;
        m_nVideoIndex = m_dwStreamCount++;
        ////                LOG("��Ƶ��id = %d\r\n",m_nVideoIndex);
        m_ratioX = vp.ratioX;
        m_ratioY = vp.ratioY;
        m_vtimebase_den = vp.timebase_den;
    }
    if (false ==ap.absent)
    {
        m_bHasAudio = true;

        m_nAudioIndex = m_dwStreamCount++;
        //                LOG("��Ƶ��id = %d\r\n",m_nAudioIndex);
        m_dwBitsPerSample = ap.bitPreSample;
        m_atimebase_den = ap.timebase_den;
    }

    return S_OK;
}

double getAACFrequency(uint32_t sampleRate)
{
    return 1024.0/sampleRate;
}

HRESULT CMp4Mux::InternalClose(bool moveMoov/* = false*/)
{
    HRESULT hr = S_OK;
    if(m_lpRecovryBuffer)
    {
        delete [] m_lpRecovryBuffer;
        m_lpRecovryBuffer = NULL;
    }

    if(m_pStream)
    {
        if(m_bHasAudio)
        {
            m_dbFrequency = getAACFrequency(m_dwFrequency);
            m_dwAudioDuration = DWORD(m_dwAudioSampleCount * m_dbFrequency + 0.5);
        }
        if(m_bHasVideo)
        {
            m_dwVideoDuration = DWORD(m_dwVideoSampleCount / m_dbFrameRate + 0.5);
        }

        m_dwDuration = m_dwVideoDuration;
        if(m_dwDuration < m_dwAudioDuration)
            m_dwDuration = m_dwAudioDuration;

        m_dwAudioDuration *= m_dwTimeScale;//m_dwFrequency;
        m_dwVideoDuration *= m_dwTimeScale;//m_dbFrameRate;
        m_dwDuration *= m_dwTimeScale;


        DWORD dwLeft;
        DWORD dwSize = (m_dwVideoSampleCount + m_dwAudioSampleCount) *
                (sizeof(STTSENTITY) +
                 sizeof(STSSENTITY) +
                 sizeof(STSCENTITY) +
                 sizeof(STSZENTITY) +
                 sizeof(STCOENTITY))+
                1024 * 1024;
        LPBYTE lpMoovData;
        std::auto_ptr<BYTE> aData(new BYTE[dwSize]);
        lpMoovData = aData.get();
        if(lpMoovData)
        {
            memset(lpMoovData,0,dwSize);

            //			LOG("audio first = %I64d,last = %I64d,len = %d\r\n",m_llAudioFirst,m_llAudioLast,(DWORD)((m_llAudioLast - m_llAudioFirst) / 10000.0));
            //			LOG("video first = %I64d,last = %I64d,len = %d\r\n",m_llVideoFirst,m_llVideoLast,(DWORD)((m_llVideoLast - m_llVideoFirst) / 10000.0));
            //			LOG("first delt = %d\r\n",(DWORD)((m_llVideoFirst - m_llAudioFirst) / 10000.0));
            //			LOG("last delt = %d\r\n",(DWORD)((m_llVideoLast - m_llAudioLast) / 10000.0));
            m_dwMoovSize = WriteMoovBox(lpMoovData);
            if (moveMoov)
                WriteMoovBox(lpMoovData);
            dwLeft = m_dwMoovSize;
            while(dwLeft)
            {
                u_int32_t write = 512 * 1024 >= dwLeft ? dwLeft : 512*1024;
                m_pStream->write(&lpMoovData[m_dwMoovSize - dwLeft],write);
                dwLeft -= write;
            }

            WriteMdatBox(m_dwDataSize);
        }
    }

    if(m_lpVideoDsiData)
    {
        delete [] m_lpVideoDsiData;
        m_lpVideoDsiData = NULL;
    }
    return hr;
}

DWORD CMp4Mux::WriteFtypBox(DWORD dwCompatibleBrands[],DWORD dwCount)
{
    DWORD dwSize;
    FTYPBOX ftypBox;
    DWORD dwMinorVersion = 0x000;
    dwSize = sizeof(FTYPBOX) + dwCount * sizeof(DWORD);
    ftypBox.dwSize = LE_BE(dwSize);
    ftypBox.dwName = ATOM_BOX_TYPE('f','t','y','p');
    ftypBox.dwMajorBrand = ATOM_BOX_TYPE('M','4','A',' ');
    ftypBox.dwMinorVersion = LE_BE(dwMinorVersion);
    m_pStream->write((LPBYTE)&ftypBox,sizeof(FTYPBOX));
    for(DWORD i = 0;i < dwCount;i++)
        m_pStream->write((LPBYTE)&dwCompatibleBrands[i],sizeof(DWORD));
    return dwSize;
}

HRESULT CMp4Mux::WriteMdatBox(DWORD dwDataSize)
{
    HRESULT hr = S_OK;
    DWORD dwSize;

    MDATBOX mdatBox;
    dwSize = sizeof(MDATBOX);
    mdatBox.dwSize = LE_BE(dwSize + dwDataSize);
    mdatBox.dwName = ATOM_BOX_TYPE('m','d','a','t');


    if(dwDataSize == 0)
    {
        m_pStream->write((LPBYTE)&mdatBox,sizeof(MDATBOX));

        m_dwDataOffset = dwSize + m_dwFtypSize;
        m_dwFileWriteOffset = m_dwDataOffset;
    }
    else
    {
        //		JIF(pMediaSeek->SetPosition(m_dwDataOffset - sizeof(MDATBOX)));
        //m_pStream->write((LPBYTE)&mdatBox,sizeof(MDATBOX));


    }
    //	pMediaSeek->Release();

    return hr;
}

struct NAL
{
    uint32_t offfset;
    uint32_t len;
};
uint32_t toBE_32(uint32_t v)
{
    uint32_t ret;
    uint8_t* len = (uint8_t*)&v;
    uint8_t* pR = (uint8_t*)&ret;
    memcpy(pR, len+3, 1);
    memcpy(pR+1, len+2, 1);
    memcpy(pR+2, len+1, 1);
    memcpy(pR+3, len, 1);
    return ret;
}

int32_t CMp4Mux::WritePayLoad(LPBYTE lpBuffer,DWORD dwSize,DWORD dwStreamID,LONGLONG llPts,LONGLONG llDts,BOOL isSyncPoint)
{
    PAYLOADINFO payLoadInfo;
    payLoadInfo.bIsKeyFrame = isSyncPoint;
    payLoadInfo.dwOffset = m_dwFileWriteOffset;
    payLoadInfo.dwSize = dwSize;
    payLoadInfo.llPts = llPts;
    payLoadInfo.llDts = llDts;


    if(dwStreamID == VIDEO_STREAM_ID)
    {
        if(m_bVideoFirst)
        {
            m_llVideoFirst = llDts;
            m_bVideoFirst = FALSE;
        }
        else
        {
            if (llDts <= m_llVideoLast)
                return -1;
            {
                double dur_90k = llDts - m_llVideoLast;
                double dur_s = dur_90k/m_vtimebase_den;
                m_dbFrameRate = 1/dur_s;
            }
            m_llVideoLast = llDts;

        }
#if 0
        LPBYTE lpBegin = lpBuffer;
        LPBYTE lpEnd = lpBegin;
        if(dwSize + 100 > MAX_PAYLOAD_SIZE)
        {
            delete [] m_lpRecovryBuffer;
            m_lpRecovryBuffer = new BYTE[dwSize + MAX_PAYLOAD_SIZE];
        }
        LPBYTE lpNewCopyPoint = m_lpRecovryBuffer;
        while(TRUE)
        {
            if(lpEnd > lpBuffer + dwSize - 1)
            {
                DWORD dwLength = lpEnd - lpBegin;

                *(LPDWORD)lpNewCopyPoint = LE_BE(dwLength);
                lpNewCopyPoint += 4;
                memcpy(lpNewCopyPoint,lpBegin,dwLength);
                lpNewCopyPoint += dwLength;
                payLoadInfo.dwSize = lpNewCopyPoint - m_lpRecovryBuffer;
                break;
            }
            if((*(LPDWORD)lpEnd == 0x01000000) || ((*(LPDWORD)lpEnd & 0x00ffffff) == 0x00010000)) // h264 startcode
            {
                if(lpEnd != lpBegin)
                {
                    DWORD dwLength = lpEnd - lpBegin;

                    *(LPDWORD)lpNewCopyPoint = LE_BE(dwLength);
                    lpNewCopyPoint += 4;
                    memcpy(lpNewCopyPoint,lpBegin,dwLength);
                    lpNewCopyPoint += dwLength;
                }

                if(*(LPDWORD)lpEnd == 0x01000000)
                {
                    lpEnd += 4;
                }
                else
                {
                    lpEnd += 3;
                }
                lpBegin = lpEnd;
                continue;
            }

            lpEnd++;
        }

        if(!m_bHasVideo) return 0;
        m_dwVideoSampleCount++;
        payLoadInfo.dwIndex = m_dwVideoSampleCount;

        DWORD dwOffset = 0;

        DWORD dwLeftSize = payLoadInfo.dwSize;
        DWORD dwTemp1 = 0,dwTemp3 = 4;
        LPBYTE lpTemp = m_lpRecovryBuffer;
        while(GetBoxSize(lpTemp,dwTemp1,dwTemp3) && dwLeftSize > dwTemp3)
        {
            if((dwTemp1 > dwLeftSize - dwTemp3) || (dwTemp1 == 0x01))
                break;
            lpTemp += 4;
            BYTE byData = *(lpTemp) & 0x1f;
            if(byData != 0x09 && byData != 0x07 && byData != 0x08 && byData != 0x06)
            {
                dwOffset = lpTemp - 4 - m_lpRecovryBuffer;
                break;
            }

            lpTemp += dwTemp1;
            dwLeftSize -= (dwTemp1 + dwTemp3);
        }

        payLoadInfo.dwSize -= dwOffset;
        m_listVideoSampleTable.push_back(payLoadInfo);
        if(m_lpVideoDsiData == NULL && isSyncPoint)
        {
            m_lpVideoDsiData = new BYTE[dwOffset];
            memcpy(m_lpVideoDsiData,m_lpRecovryBuffer,dwOffset);
            LPBYTE lpTemp = m_lpVideoDsiData;
            LPBYTE lpBegin = NULL;
            LPBYTE lpEnd = NULL;
            DWORD dwSize,dwNalSize;

            while(TRUE)
            {
                if(lpTemp > (m_lpVideoDsiData + dwOffset - 1))
                    break;

                if(!GetBoxSize(lpTemp,dwSize,dwNalSize))
                    break;

                if((*(lpTemp + 4) & 0x1f) == 0x07)
                {
                    *(DWORD*)lpTemp = 0x01000000;
                    lpBegin = lpTemp;
                }

                if((*(lpTemp + 4) & 0x1f) == 0x08)
                {
                    *(DWORD*)lpTemp = 0x01000000;
                    lpEnd = lpTemp + dwSize + 4;
                }

                lpTemp += dwSize + 4;
            }
            if(lpEnd == NULL || lpBegin == NULL)
            {
                delete [] m_lpVideoDsiData;
                m_lpVideoDsiData = NULL;
                m_dwVideoDsiLen = 0;
            }
            else
            {
                m_dwVideoDsiLen = abs(lpEnd - lpBegin)>=(m_lpVideoDsiData + dwOffset - lpBegin)? (m_lpVideoDsiData + dwOffset - lpBegin):abs(lpEnd - lpBegin);
                if(m_dwVideoDsiLen > dwOffset)
                {
                    delete [] m_lpVideoDsiData;
                    m_lpVideoDsiData = NULL;
                    m_dwVideoDsiLen = 0;
                }
                else
                    memcpy(m_lpVideoDsiData,lpBegin,m_dwVideoDsiLen);
            }
        }

        int fix = 0;
        if (isSyncPoint)
        {
            payLoadInfo.dwSize += 10;
            fix = 10;
        }
        m_pStream->write(m_lpRecovryBuffer + dwOffset-fix,payLoadInfo.dwSize);
        #endif

        ///////splitNAL///////
        uint8_t* buf = lpBuffer;
        uint32_t size = dwSize;
        NAL _nals[100];
        if (size < 4 || buf == NULL)
            return -1;
        uint32_t idx = 0;

        bool foundFirstStartCode = false;
        memset(_nals, 0, sizeof(_nals));
        for (uint32_t i = 4; i < size && idx < sizeof(_nals)/sizeof(NAL); ++i)
        {
            if (0x01 == buf[i-1] && 0x00 == buf[i-2] && 0x00 == buf[i-3])
            {
                if (false == foundFirstStartCode)
                {
                    foundFirstStartCode = true;
                    _nals[idx].offfset = i;
                    idx++;
                    continue;
                }
                _nals[idx].offfset = i;
                _nals[idx-1].len = i - _nals[idx-1].offfset - (buf[i-4] == 0 ?4:3);
                ++idx;
            }
        }
        if (idx > 0)
            _nals[idx-1].len = size - _nals[idx-1].offfset;
        //////////////////////////////////////////////////////////////
        uint8_t* out = m_lpRecovryBuffer;
        uint32_t outS = 0;
        uint32_t i = 0;
        int32_t spsIdx, ppsIdx;
        spsIdx = ppsIdx = -1;
        while(_nals[i].len != 0
              && _nals[i].offfset != 0)
        {
            uint8_t type = buf[_nals[i].offfset] & 0x1F;
            switch(type)
            {
            case 7: //SPS
            {
                spsIdx = i;
                parse_sps(buf+_nals[i].offfset, _nals[i].len);
                break;
            }
            case 9:
                break;
            case 12:
                break;
            case 8: //SPS
            {
                ppsIdx = i;
            }
            default:
            {
                uint32_t be = toBE_32(_nals[i].len);
                memcpy(out+outS, &be, sizeof(uint32_t));
                outS += sizeof(uint32_t);
                memcpy(out+outS, buf+_nals[i].offfset, _nals[i].len);
                outS += _nals[i].len;
            }
            }
            ++i;
        }
        ///////////////copy sps/pps to dsi/////////
        if (ppsIdx != -1
                && spsIdx != -1)
        {
            m_lpVideoDsiData = new uint8_t[_nals[spsIdx].len+_nals[ppsIdx].len+8];
            m_dwVideoDsiLen = 0;
            uint32_t startcode = 0x1000000;
            memcpy(m_lpVideoDsiData+m_dwVideoDsiLen, &startcode, sizeof(uint32_t));
            m_dwVideoDsiLen += sizeof(uint32_t);
            memcpy(m_lpVideoDsiData+m_dwVideoDsiLen, buf+_nals[spsIdx].offfset, _nals[spsIdx].len);
            m_dwVideoDsiLen += _nals[spsIdx].len;
            // pps
            memcpy(m_lpVideoDsiData+m_dwVideoDsiLen, &startcode, sizeof(uint32_t));
            m_dwVideoDsiLen += sizeof(uint32_t);
            memcpy(m_lpVideoDsiData+m_dwVideoDsiLen, buf+_nals[ppsIdx].offfset, _nals[ppsIdx].len);
            m_dwVideoDsiLen += _nals[ppsIdx].len;
        }
        //////update box info and write data to sink ////////////
        if(!m_bHasVideo) return 0;
        m_dwVideoSampleCount++;
        payLoadInfo.dwIndex = m_dwVideoSampleCount;
        payLoadInfo.dwSize = outS;
        m_listVideoSampleTable.push_back(payLoadInfo);

        m_pStream->write(out,payLoadInfo.dwSize);
        outS = 0;
    }
    else if(dwStreamID == AUDIO_STREAM_ID)
    {
        if(m_bAudioFirst)
        {
            m_llAudioFirst = llDts;
            m_bAudioFirst = FALSE;
        }
        else
        {
            if (llDts <= m_llAudioLast)
                return -1;
            m_llAudioLast = llDts;
        }

        if(!m_bHasAudio) return 0;

        bool bCrcPresent = ((lpBuffer[1] & 0x1) == 0x0) ? true : false;
        uint32_t crcLen = bCrcPresent ? 2 : 0;
        m_dwAudioSampleCount++;
        payLoadInfo.dwIndex = m_dwAudioSampleCount;
        payLoadInfo.dwSize = dwSize - ADTS_HEADER_LENGTH - crcLen;
        m_listAudioSampleTable.push_back(payLoadInfo);
        if(m_byAudioDsiData[0] == 0) //
        {
            // pase AAC ADTS
            this->ParseADTSHeader(lpBuffer,dwSize);
            // genDis
            INT object_type = 2;
            INT nIndex = GetSamplingFrequencyIndex(m_dwFrequency);
            m_byAudioDsiData[0] = (object_type << 3) | (nIndex >> 1);
            m_byAudioDsiData[1] = BYTE(((nIndex & 1) << 7) | (m_dwChannelCount << 3));
        }
        m_pStream->write(&lpBuffer[ADTS_HEADER_LENGTH + crcLen],dwSize - ADTS_HEADER_LENGTH - crcLen);
    }
    else
    {
        //		LOG("δ֪��id = %d��size = %d\r\n",dwStreamID,dwSize);
    }
    m_dwDataSize += payLoadInfo.dwSize;
    m_dwFileWriteOffset += payLoadInfo.dwSize;

    return m_dwFileWriteOffset;
}
#include "h264_parser.h"
bool CMp4Mux::parse_sps(uint8_t* bytes, uint32_t size)
{
    h264_decode_t dec;
    memset(&dec, 0, sizeof(dec));
    h264_parse_sequence_parameter_set(&dec, bytes, size);
    m_dwWidth = dec.pic_width;
    m_dwHeight = dec.pic_height;
    m_nProfile = dec.profile;
    m_nLevel = dec.level;
    return true;
}
bool CMp4Mux::ParseADTSHeader(uint8_t* bytes, uint32_t size)
{
    if (bytes[0] != 0xff || size < ADTS_HEADER_LENGTH)
        return false;
    m_dwFrequency = GetSamplingFrequency( ( bytes[2] & 0x3C) >> 2);
    m_dwChannelCount   = ((bytes[2] & 0x01) << 2) |
            ((bytes[3] & 0xC0) >> 6);
    return true;
}

DWORD CMp4Mux::WriteMoovBox(LPBYTE lpData)
{
    m_dwCurrentTick = 0;
    DWORD dwBoxSize = 0;
    LPMOOVBOX lpMoovBox = (LPMOOVBOX)lpData;
    lpMoovBox->dwName = ATOM_BOX_TYPE('m','o','o','v');
    dwBoxSize += sizeof(MOOVBOX);
    dwBoxSize += WriteMvhdBox(&lpData[dwBoxSize]);
    for(DWORD i = 0;i < m_dwStreamCount;i++)
    {
        DWORD dwTrackID;
        if(i == m_nVideoIndex && m_bHasVideo)
            dwTrackID = VIDEO_STREAM_ID;
        else if(i == m_nAudioIndex && m_bHasAudio)
            dwTrackID = AUDIO_STREAM_ID;
        else
            continue;
        dwBoxSize += WriteTrakBox(&lpData[dwBoxSize],dwTrackID);
    }
    lpMoovBox->dwSize = LE_BE(dwBoxSize);
    return dwBoxSize;
}

DWORD CMp4Mux::WriteMvhdBox(LPBYTE lpData)
{
    LPMVHDBOX lpMvhdBox = (LPMVHDBOX)lpData;
    lpMvhdBox->dwSize = LE_BE((DWORD)sizeof(MVHDBOX));
    lpMvhdBox->dwName = ATOM_BOX_TYPE('m','v','h','d');
    lpMvhdBox->dwCreateTime = LE_BE(m_dwCurrentTick);
    lpMvhdBox->dwModifyTime = LE_BE(m_dwCurrentTick);
    lpMvhdBox->dwTimeScale = LE_BE(m_dwTimeScale);
    lpMvhdBox->dwDuration = LE_BE(m_dwDuration);
    lpMvhdBox->dwPlaySpeed = LE_BE((DWORD)0x00010000);
    lpMvhdBox->wVolume = 1;
    lpMvhdBox->dwMatrix[0] = LE_BE((DWORD)0x00010000);
    lpMvhdBox->dwMatrix[4] = LE_BE((DWORD)0x00010000);
    lpMvhdBox->dwMatrix[8] = LE_BE((DWORD)0x40000000);
    lpMvhdBox->dwNextTrackID = LE_BE(m_dwStreamCount + 1);
    return sizeof(MVHDBOX);
}

DWORD CMp4Mux::WriteTrakBox(LPBYTE lpData,DWORD dwTrackID)
{
    DWORD dwBoxSize = 0;
    LPTRAKBOX lpTrakBox = (LPTRAKBOX)lpData;
    lpTrakBox->dwName = ATOM_BOX_TYPE('t','r','a','k');
    dwBoxSize += sizeof(TRAKBOX);
    dwBoxSize += WriteTkhdBox(&lpData[dwBoxSize],dwTrackID);
    if(0/*dwTrackID == VIDEO_STREAM_ID*/) //wzd
        dwBoxSize += WriteEdtsBox(&lpData[dwBoxSize],dwTrackID);
    dwBoxSize += WriteMdiaBox(&lpData[dwBoxSize],dwTrackID);
    lpTrakBox->dwSize = LE_BE(dwBoxSize);
    return dwBoxSize;
}

DWORD CMp4Mux::WriteTkhdBox(LPBYTE lpData,DWORD dwTrackID)
{
    LPTKHDBOX lpTkhdBox = (LPTKHDBOX)lpData;
    lpTkhdBox->byFlags[2] = 0x7; // for itune
    lpTkhdBox->dwSize = LE_BE((DWORD)sizeof(TKHDBOX));
    lpTkhdBox->dwName = ATOM_BOX_TYPE('t','k','h','d');
    lpTkhdBox->dwCreateTime = LE_BE(m_dwCurrentTick);
    lpTkhdBox->dwModifyTime = LE_BE(m_dwCurrentTick);
    lpTkhdBox->dwTrackID = LE_BE(dwTrackID + 1);

    if(dwTrackID == VIDEO_STREAM_ID)
    {
        lpTkhdBox->dwDuration = LE_BE(m_dwVideoDuration);
        lpTkhdBox->dwWidth = LE_BE(((DWORD)(m_dwWidth))<< 16);
        lpTkhdBox->dwHeight = LE_BE(m_dwHeight << 16);
    }
    else if(dwTrackID == AUDIO_STREAM_ID)
    {
        lpTkhdBox->dwDuration = LE_BE(m_dwAudioDuration);
        lpTkhdBox->wVolume = LE_BE((WORD)0x0100);
    }

    lpTkhdBox->dwMatrix[0] = LE_BE((DWORD)0x00010000);
    lpTkhdBox->dwMatrix[4] = LE_BE((DWORD)0x00010000);
    lpTkhdBox->dwMatrix[8] = LE_BE((DWORD)0x40000000);

    return sizeof(TKHDBOX);
}

DWORD CMp4Mux::WriteEdtsBox(LPBYTE lpData,DWORD dwTrackID)
{
    DWORD dwBoxSize = 0;
    LPEDTSBOX lpEdtsBox = (LPEDTSBOX)lpData;
    lpEdtsBox->dwName = ATOM_BOX_TYPE('e','d','t','s');
    dwBoxSize += sizeof(EDTSBOX);
    dwBoxSize += WriteElstBox(&lpData[dwBoxSize],dwTrackID);
    lpEdtsBox->dwSize = LE_BE(dwBoxSize);
    return dwBoxSize;
}

DWORD CMp4Mux::WriteElstBox(LPBYTE lpData,DWORD /*dwTrackID*/)
{
    LONGLONG llDelt = (m_llAudioFirst - m_llVideoFirst) / 100;
    DWORD dwDelt = DWORD(llDelt < 0 ? -llDelt : llDelt);
    DWORD dwTime = (llDelt < 0) ? -1 : 0;
    LPELSTBOX lpElstBox = (LPELSTBOX)lpData;
    lpElstBox->dwSize = LE_BE((DWORD)sizeof(ELSTBOX));
    lpElstBox->dwName = ATOM_BOX_TYPE('e','l','s','t');
    lpElstBox->dwEntryCount = LE_BE((DWORD)0x1);
    lpElstBox->dwDuration = LE_BE(dwDelt);
    lpElstBox->dwMediaTime = LE_BE(dwTime);
    lpElstBox->wInteger = LE_BE((WORD)0x1);
    lpElstBox->wFraction = LE_BE((WORD)0x0);
    return sizeof(ELSTBOX);
}

DWORD CMp4Mux::WriteMdiaBox(LPBYTE lpData,DWORD dwTrackID)
{
    DWORD dwBoxSize = 0;
    LPMDIABOX lpMdiaBox = (LPMDIABOX)lpData;
    lpMdiaBox->dwName = ATOM_BOX_TYPE('m','d','i','a');
    dwBoxSize += sizeof(MDIABOX);
    dwBoxSize += WriteMdhdBox(&lpData[dwBoxSize],dwTrackID);
    dwBoxSize += WriteHdlrBox(&lpData[dwBoxSize],dwTrackID);
    dwBoxSize += WriteMinfBox(&lpData[dwBoxSize],dwTrackID);
    lpMdiaBox->dwSize = LE_BE(dwBoxSize);
    return dwBoxSize;
}

DWORD CMp4Mux::WriteMdhdBox(LPBYTE lpData,DWORD dwTrackID)
{
    LPMDHDBOX lpMdhdBox = (LPMDHDBOX)lpData;
    lpMdhdBox->dwSize = LE_BE((DWORD)sizeof(MDHDBOX));
    lpMdhdBox->dwName = ATOM_BOX_TYPE('m','d','h','d');
    lpMdhdBox->dwCreateTime = LE_BE(m_dwCurrentTick);
    lpMdhdBox->dwModifyTime = LE_BE(m_dwCurrentTick);
    if(dwTrackID == VIDEO_STREAM_ID)
    {
        lpMdhdBox->dwTimeScale = LE_BE(m_dwTimeScale);
        lpMdhdBox->dwDuration = LE_BE(m_dwVideoDuration);
    }
    else if(dwTrackID == AUDIO_STREAM_ID)
    {
        lpMdhdBox->dwTimeScale = LE_BE(m_dwTimeScale);
        lpMdhdBox->dwDuration = LE_BE(m_dwAudioDuration);
    }

    lpMdhdBox->wLanguage = LE_BE((WORD)0x55c4);
    return sizeof(MDHDBOX);
}

DWORD CMp4Mux::WriteHdlrBox(LPBYTE lpData,DWORD dwTrackID)
{
    DWORD dwBoxSize = 0;
    INT nStringLength = 0;
    const char VideoComponentName[] = "CTVIT0 Video Handler";
    const char AudioComponentName[] = "CTVIT0 Audio Handler";
    LPHDLRBOX lpHdlrBox = (LPHDLRBOX)lpData;
    lpHdlrBox->dwName = ATOM_BOX_TYPE('h','d','l','r');
    lpHdlrBox->dwType = ATOM_BOX_TYPE('m','h','l','r');
    dwBoxSize += sizeof(HDLRBOX);
    LPBYTE lpTemp = lpData + dwBoxSize;
    if(dwTrackID == VIDEO_STREAM_ID)
    {
        nStringLength = sizeof(VideoComponentName);
        lpHdlrBox->dwSubType = ATOM_BOX_TYPE('v','i','d','e');
        memcpy(lpTemp,VideoComponentName,nStringLength);
    }
    else if(dwTrackID == AUDIO_STREAM_ID)
    {
        nStringLength = sizeof(AudioComponentName);
        lpHdlrBox->dwSubType = ATOM_BOX_TYPE('s','o','u','n');
        memcpy(lpTemp,AudioComponentName,nStringLength);
    }
    dwBoxSize += nStringLength;
    lpHdlrBox->dwSize = LE_BE(dwBoxSize);
    return dwBoxSize;
}

DWORD CMp4Mux::WriteMinfBox(LPBYTE lpData,DWORD dwTrackID)
{
    DWORD dwBoxSize = 0;
    LPMINFBOX lpMinfBox = (LPMINFBOX)lpData;
    lpMinfBox->dwName = ATOM_BOX_TYPE('m','i','n','f');
    dwBoxSize += sizeof(MINFBOX);
    if(dwTrackID == VIDEO_STREAM_ID)
        dwBoxSize += WriteVmhdBox(&lpData[dwBoxSize],dwTrackID);
    else if(dwTrackID == AUDIO_STREAM_ID)
        dwBoxSize += WriteSmhdBox(&lpData[dwBoxSize],dwTrackID);
    dwBoxSize += WriteDinfBox(&lpData[dwBoxSize],dwTrackID);
    dwBoxSize += WriteStblBox(&lpData[dwBoxSize],dwTrackID);
    lpMinfBox->dwSize = LE_BE(dwBoxSize);
    return dwBoxSize;
}

DWORD CMp4Mux::WriteVmhdBox(LPBYTE lpData,DWORD /*dwTrackID*/)
{
    LPVMHDBOX lpVmhdBox = (LPVMHDBOX)lpData;
    lpVmhdBox->dwSize = LE_BE((DWORD)sizeof(VMHDBOX));
    lpVmhdBox->dwName = ATOM_BOX_TYPE('v','m','h','d');
    lpVmhdBox->byFlags[2] = 0x1;
    return sizeof(VMHDBOX);
}

DWORD CMp4Mux::WriteSmhdBox(LPBYTE lpData,DWORD /*dwTrackID*/)
{
    LPSMHDBOX lpSmhdBox = (LPSMHDBOX)lpData;
    lpSmhdBox->dwSize = LE_BE((DWORD)sizeof(SMHDBOX));
    lpSmhdBox->dwName = ATOM_BOX_TYPE('s','m','h','d');
    return sizeof(SMHDBOX);
}

DWORD CMp4Mux::WriteDinfBox(LPBYTE lpData,DWORD dwTrackID)
{
    DWORD dwBoxSize = 0;
    LPDINFBOX lpDinfBox = (LPDINFBOX)lpData;
    lpDinfBox->dwName = ATOM_BOX_TYPE('d','i','n','f');
    dwBoxSize += sizeof(DINFBOX);
    dwBoxSize += WriteDrefBox(&lpData[dwBoxSize],dwTrackID);
    lpDinfBox->dwSize = LE_BE(dwBoxSize);
    return dwBoxSize;
}

DWORD CMp4Mux::WriteDrefBox(LPBYTE lpData,DWORD /*dwTrackID*/)
{
    DWORD dwBoxSize = 0;
    LPDREFBOX lpDrefBox = (LPDREFBOX)lpData;
    lpDrefBox->dwName = ATOM_BOX_TYPE('d','r','e','f');
    lpDrefBox->dwEntryCount = LE_BE((DWORD)0x1);
    dwBoxSize += sizeof(DREFBOX);
    dwBoxSize += WriteUrlBox(&lpData[dwBoxSize],(LPTSTR)0x01000000);
    lpDrefBox->dwSize = LE_BE(dwBoxSize);
    return dwBoxSize;
}

DWORD CMp4Mux::WriteUrlBox(LPBYTE lpData,LPTSTR lpUrl)
{
    DWORD dwBoxSize = 0;
    LPURLBOX lpUrlBox = (LPURLBOX)lpData;
    lpUrlBox->dwName = ATOM_BOX_TYPE('u','r','l',' ');
    dwBoxSize += sizeof(URLBOX);
    memcpy(&lpData[dwBoxSize],&lpUrl,4);
    dwBoxSize += 4;
    lpUrlBox->dwSize = LE_BE(dwBoxSize);
    return dwBoxSize;
}

DWORD CMp4Mux::WriteStblBox(LPBYTE lpData,DWORD dwTrackID)
{
    DWORD dwBoxSize = 0;
    LPSTBLBOX lpStblBox = (LPSTBLBOX)lpData;
    lpStblBox->dwName = ATOM_BOX_TYPE('s','t','b','l');
    dwBoxSize += sizeof(STBLBOX);

    dwBoxSize += WriteStsdBox(&lpData[dwBoxSize],dwTrackID);
    dwBoxSize += WriteStszBox(&lpData[dwBoxSize],dwTrackID);
    dwBoxSize += WriteStscBox(&lpData[dwBoxSize],dwTrackID);
    dwBoxSize += WriteSttsBox(&lpData[dwBoxSize],dwTrackID);

    if(dwTrackID == VIDEO_STREAM_ID)
    {
        dwBoxSize += WriteCttsBox(&lpData[dwBoxSize],dwTrackID);
        dwBoxSize += WriteStssBox(&lpData[dwBoxSize],dwTrackID);
    }


    dwBoxSize += WriteStcoBox(&lpData[dwBoxSize],dwTrackID);
    lpStblBox->dwSize = LE_BE(dwBoxSize);
    return dwBoxSize;
}

DWORD CMp4Mux::WriteStsdBox(LPBYTE lpData,DWORD dwTrackID)
{
    DWORD dwBoxSize = 0;
    LPSTSDBOX lpStsdBox = (LPSTSDBOX)lpData;

    lpStsdBox->dwName = ATOM_BOX_TYPE('s','t','s','d');
    dwBoxSize += sizeof(STSDBOX);
    lpStsdBox->dwSampleDescriptionCount = LE_BE((DWORD)0x1);
    if(dwTrackID == VIDEO_STREAM_ID)
    {
        dwBoxSize += WriteVisualSampleEntry(&lpData[dwBoxSize],dwTrackID);
    }
    else if(dwTrackID == AUDIO_STREAM_ID)
    {
        dwBoxSize += WriteAudioSampleEntry(&lpData[dwBoxSize],dwTrackID);
    }
    lpStsdBox->dwSize = LE_BE(dwBoxSize);
    return dwBoxSize;
}

DWORD CMp4Mux::WriteVisualSampleEntry(LPBYTE lpData,DWORD /*dwTrackID*/)
{
    DWORD dwBoxSize = 0;
    LPVISUALSAMPLEENTRY lpVisualSampleEntryBox = (LPVISUALSAMPLEENTRY)lpData;
    lpVisualSampleEntryBox->dwName = ATOM_BOX_TYPE('a','v','c','1');
    dwBoxSize += sizeof(VISUALSAMPLEENTRY);
    lpVisualSampleEntryBox->wDataRefIndex = LE_BE((WORD)0x1);
    lpVisualSampleEntryBox->wWidth = LE_BE((WORD)m_dwWidth);
    lpVisualSampleEntryBox->wHeight = LE_BE((WORD)m_dwHeight);
    lpVisualSampleEntryBox->dwHorizontalResolution = LE_BE((DWORD)0x00480000);
    lpVisualSampleEntryBox->dwVerticalResolution = LE_BE((DWORD)0x00480000);
    lpVisualSampleEntryBox->wFrameCount = LE_BE((WORD)0x1);
    lpVisualSampleEntryBox->wDepth = LE_BE((WORD)0x18);
    lpVisualSampleEntryBox->wPreDefined2 = LE_BE((WORD)0xffff);
    dwBoxSize += WriteAvcCBox(&lpData[dwBoxSize]);
    lpVisualSampleEntryBox->dwSize = LE_BE(dwBoxSize);
    return dwBoxSize;
}

DWORD CMp4Mux::WriteAudioSampleEntry(LPBYTE lpData,DWORD dwTrackID)
{
    DWORD dwBoxSize = 0;
    LPAUDIOSAMPLEENTRY lpAudioSampleEntryBox = (LPAUDIOSAMPLEENTRY)lpData;
    lpAudioSampleEntryBox->dwName = ATOM_BOX_TYPE('m','p','4','a');
    dwBoxSize += sizeof(AUDIOSAMPLEENTRY);
    lpAudioSampleEntryBox->wDataRefIndex = LE_BE((WORD)0x01);
    lpAudioSampleEntryBox->wChannelCount = LE_BE((WORD)m_dwChannelCount);
    lpAudioSampleEntryBox->wSampleSize = LE_BE((WORD)m_dwBitsPerSample);
    lpAudioSampleEntryBox->dwSampleRate = LE_BE(m_dwFrequency << 16);

    dwBoxSize += WriteEsdsBox(&lpData[dwBoxSize],dwTrackID);

    lpAudioSampleEntryBox->dwSize = LE_BE(dwBoxSize);
    return dwBoxSize;
}

DWORD CMp4Mux::WriteAvcCBox(LPBYTE lpData)
{
    DWORD dwBoxSize = 0;
    LPAVCCBOX lpAvcCBox = (LPAVCCBOX)lpData;
    lpAvcCBox->dwName = ATOM_BOX_TYPE('a','v','c','C');
    dwBoxSize += sizeof(AVCCBOX);

    LPBYTE lpTemp = &lpData[dwBoxSize];
    *lpTemp++ = 0x1;
    *lpTemp++ = m_nProfile;
    *lpTemp++ = m_nProfileCompatibility;
    *lpTemp++ = m_nLevel;
    *lpTemp++ = 0xff;
    dwBoxSize += 5;
    if(m_lpVideoDsiData)
    {
        LPBYTE lpBegin = m_lpVideoDsiData;
        LPBYTE lpEnd = lpBegin;

        while(lpEnd <= m_lpVideoDsiData + m_dwVideoDsiLen)
        {
            if(*(LPDWORD)lpEnd == 0x01000000 || (lpEnd == m_lpVideoDsiData + m_dwVideoDsiLen))
            {
                if(lpEnd != lpBegin)
                {
                    *lpTemp++ = 0x1;
                    INT nSize = lpEnd - lpBegin;
                    *(LPWORD)lpTemp = LE_BE((WORD)nSize);
                    lpTemp += 2;
                    memcpy(lpTemp,lpBegin,nSize);
                    lpTemp += nSize;
                    dwBoxSize += nSize + 3;
                }
                lpEnd += 4;
                lpBegin = lpEnd;
                continue;
            }
            lpEnd++;
        }
    }

    lpAvcCBox->dwSize = LE_BE(dwBoxSize);
    return dwBoxSize;
}

DWORD CMp4Mux::WriteEsdsBox(LPBYTE lpData,DWORD dwTrackID)
{
    DWORD dwBoxSize = 0;
    LPESDSBOX lpEsdsBox = (LPESDSBOX)lpData;
    lpEsdsBox->dwName = ATOM_BOX_TYPE('e','s','d','s');
    dwBoxSize = sizeof(ESDSBOX) - 1;
    LPBYTE lpEsds = &lpEsdsBox->byData[0];
    if(dwTrackID == VIDEO_STREAM_ID)
    {

    }
    else if(dwTrackID == AUDIO_STREAM_ID)
    {
        INT nDsiLen = 2 ? CompuLen(2) : 0;
        lpEsds += AddDes(lpEsds,0x03,3 + CompuLen(13 + nDsiLen) + CompuLen(1));
        *(LPWORD)lpEsds = LE_BE((WORD)dwTrackID);lpEsds += 2;
        *lpEsds++ = 0x00;
        lpEsds += AddDes(lpEsds,0x04,13 + CompuLen(nDsiLen));
        *lpEsds++ = 0x40;
        *lpEsds++ = 0x15;
        *lpEsds++ = 0x00;
        *((LPWORD)lpEsds) = LE_BE((WORD)0x0);lpEsds += 2;
        *(LPDWORD)lpEsds = LE_BE((DWORD)0xc5c1);lpEsds += 4;
        *(LPDWORD)lpEsds = LE_BE((DWORD)0x0);lpEsds += 4;
        if(nDsiLen)
        {
            lpEsds += AddDes(lpEsds,0x05,2);
            memcpy(lpEsds,m_byAudioDsiData,2);
            lpEsds += 2;
        }

        lpEsds += AddDes(lpEsds,0x06,1);
        *lpEsds++ = 0x02;
    }

    dwBoxSize += lpEsds - &lpEsdsBox->byData[0];
    lpEsdsBox->dwSize = LE_BE(dwBoxSize);
    return dwBoxSize;
}

DWORD CMp4Mux::WriteSttsBox(LPBYTE lpData,DWORD dwTrackID)
{
    DWORD dwBoxSize = 0;
    LPSTTSBOX lpSttsBox = (LPSTTSBOX)lpData;
    LPSTTSENTITY lpSttsEntity = &lpSttsBox->sEntity[0];
    lpSttsBox->dwName = ATOM_BOX_TYPE('s','t','t','s');
    dwBoxSize += sizeof(STTSBOX) - sizeof(STTSENTITY);
    DWORD dwEntityCount = 0;
    double timebase_den = 1.0;
    std::list<PAYLOADINFO> *listSample;
    if(dwTrackID == VIDEO_STREAM_ID)
    {
        listSample = &m_listVideoSampleTable;
        timebase_den = m_vtimebase_den;
    }
    else if(dwTrackID == AUDIO_STREAM_ID)
    {
        listSample = &m_listAudioSampleTable;
        timebase_den = m_atimebase_den;
    }

    std::list<PAYLOADINFO>::iterator it;
    PAYLOADINFO lastPayLoad,curPayLoad;
    DWORD lastDuration = 0;
    DWORD dwDuration = 0;
    DWORD dwSampleCount = 1;
    if(listSample->size() > 1)
    {
        it = listSample->begin();
        lastPayLoad = *it;
        curPayLoad = *(++it);
        lastDuration = (DWORD)((double)(curPayLoad.llDts - lastPayLoad.llDts) / timebase_den * m_dwTimeScale);
        for (;it != listSample->end();++it)
        {
            curPayLoad = *it;
            dwDuration = (DWORD)((double)(curPayLoad.llDts - lastPayLoad.llDts) / timebase_den * m_dwTimeScale);
            if (lastDuration == dwDuration)
            {
                ++dwSampleCount;
                lastPayLoad = curPayLoad;
                continue;
            }
            lpSttsEntity->dwSampleDuration = LE_BE(lastDuration);
            lpSttsEntity->dwSampleCount = LE_BE(dwSampleCount);
            dwBoxSize += sizeof(STTSENTITY);
            lpSttsEntity++;
            dwEntityCount++;
            lastDuration = dwDuration;
            lastPayLoad = curPayLoad;
            dwSampleCount = 1;
        }
    }
    else if(listSample->size() == 1)
    {
        lastPayLoad = *(listSample->begin());
        dwDuration = dwDuration = (DWORD)((double)lastPayLoad.llDts / timebase_den * m_dwTimeScale);
        ++dwSampleCount;
    }

    lpSttsEntity->dwSampleDuration = LE_BE(dwDuration);
    lpSttsEntity->dwSampleCount = LE_BE(dwSampleCount);
    dwBoxSize += sizeof(STTSENTITY);
    lpSttsEntity++;
    dwEntityCount++;

    lpSttsBox->dwCount = LE_BE(dwEntityCount);
    lpSttsBox->dwSize = LE_BE(dwBoxSize);
    // check
    lpSttsEntity = &lpSttsBox->sEntity[0];
    DWORD dwErrDuration = 0;
    for(DWORD i = 0;i < dwEntityCount;i++)
    {
        dwErrDuration = LE_BE(lpSttsEntity->dwSampleDuration);
        if(dwErrDuration > dwDuration * 10)
        {
            //lpSttsEntity->dwSampleDuration = LE_BE(dwDuration);
        }
        lpSttsEntity++;
    }
    return dwBoxSize;
}

DWORD CMp4Mux::WriteCttsBox(LPBYTE pBuffer,DWORD nTrackID)
{
    DWORD dwBoxSize = 0;
    LPCTTSBOX lpCttsBox = (LPCTTSBOX)pBuffer;
    LPCTTSENTITY lpCttsEntity = &lpCttsBox->sEntity[0];
    lpCttsBox->dwName = ATOM_BOX_TYPE('c','t','t','s');
    dwBoxSize += sizeof(CTTSBOX) - sizeof(CTTSENTITY);


    std::list<PAYLOADINFO>* listSample;
    double timebase_den = 1.0;
    if(nTrackID == VIDEO_STREAM_ID)
    {
        listSample = &m_listVideoSampleTable;
        timebase_den = m_vtimebase_den;
    }
    else if(nTrackID == AUDIO_STREAM_ID)
    {
        listSample = &m_listAudioSampleTable;
        timebase_den = m_atimebase_den;
    }

    std::list<PAYLOADINFO>::iterator it;
    PAYLOADINFO curPayLoad;
    LONGLONG llOffset = 0;
    DWORD dwOffset = 0;
    DWORD dwEntityCount = 0;

    if(listSample->size() > 1)
    {
        DWORD dwSampleCount = 0;
        PAYLOADINFO lastPayload = *(listSample->begin());
        for (it = listSample->begin();it != listSample->end();++it)
        {
            curPayLoad = *it;
            llOffset = (curPayLoad.llPts - curPayLoad.llDts);

            dwOffset = (DWORD)((double)llOffset / timebase_den * m_dwTimeScale);
            if (llOffset == lastPayload.llPts-lastPayload.llDts)
            {
                dwSampleCount++;
                continue;
            }
            DWORD offset = (DWORD)((double)(lastPayload.llPts - lastPayload.llDts) / timebase_den * m_dwTimeScale);

            lpCttsEntity->dwSampleOffset = LE_BE(offset);
            lpCttsEntity->dwSampleCount = LE_BE(dwSampleCount);
            lpCttsEntity++;
            dwEntityCount++;
            dwBoxSize += sizeof(CTTSENTITY);

            lastPayload = curPayLoad;
            dwSampleCount = 1;
        }

        DWORD offset = (DWORD)((double)(lastPayload.llPts - lastPayload.llDts) / timebase_den * m_dwTimeScale);

        lpCttsEntity->dwSampleOffset = LE_BE(offset);
        lpCttsEntity->dwSampleCount = LE_BE(dwSampleCount);
        lpCttsEntity++;
        dwEntityCount++;
        dwBoxSize += sizeof(CTTSENTITY);

        lpCttsBox->dwCount = LE_BE(dwEntityCount);
    }

    lpCttsBox->dwSize = LE_BE(dwBoxSize);
    return dwBoxSize;
}

DWORD CMp4Mux::WriteStssBox(LPBYTE lpData,DWORD /*dwTrackID*/)
{
    DWORD dwBoxSize = 0;
    LPSTSSBOX lpStssBox = (LPSTSSBOX)lpData;
    LPSTSSENTITY lpStssEntity = &lpStssBox->sEntity[0];
    lpStssBox->dwName = ATOM_BOX_TYPE('s','t','s','s');
    dwBoxSize += sizeof(STSSBOX) - sizeof(STSSENTITY);
    DWORD dwEntityCount = 0;
    if(m_listVideoSampleTable.size() > 0)
    {
        std::list<PAYLOADINFO>::iterator it;
        for (it = m_listVideoSampleTable.begin();it != m_listVideoSampleTable.end();++it)
        {
            PAYLOADINFO payLoad = *it;
            if(payLoad.bIsKeyFrame)
            {
                lpStssEntity->dwKeyFrameNum = LE_BE(payLoad.dwIndex);
                lpStssEntity++;
                dwEntityCount++;
                dwBoxSize += sizeof(STSSENTITY);
            }
        }
    }

    lpStssBox->dwCount = LE_BE(dwEntityCount);
    lpStssBox->dwSize = LE_BE(dwBoxSize);
    return dwBoxSize;
}

DWORD CMp4Mux::WriteStscBox(LPBYTE lpData,DWORD /*dwTrackID*/)
{
    DWORD dwBoxSize = 0;
    LPSTSCBOX lpStscBox = (LPSTSCBOX)lpData;
    LPSTSCENTITY lpStscEntity = &lpStscBox->sEntity[0];
    lpStscBox->dwName = ATOM_BOX_TYPE('s','t','s','c');
    dwBoxSize += sizeof(STSCBOX) - sizeof(STSCENTITY);
    DWORD dwEntityCount = 102;

    for (int i = 1; i <= dwEntityCount; ++i)
    {
    lpStscEntity->dwFirstChunk = LE_BE((DWORD)i);
    lpStscEntity->dwSamplePerChunk = LE_BE((DWORD)0x1);
    lpStscEntity->dwSampleDescriptionID = LE_BE((DWORD)0x1);
    dwBoxSize += sizeof(STSCENTITY);
    lpStscEntity++;
    }
    lpStscBox->dwCount = LE_BE(dwEntityCount);
    lpStscBox->dwSize = LE_BE(dwBoxSize);
    return dwBoxSize;
}

DWORD CMp4Mux::WriteStszBox(LPBYTE lpData,DWORD dwTrackID)
{
    DWORD dwBoxSize = 0;
    LPSTSZBOX lpStszBox = (LPSTSZBOX)lpData;
    LPSTSZENTITY lpStszEntity = &lpStszBox->sEntity[0];
    lpStszBox->dwName = ATOM_BOX_TYPE('s','t','s','z');
    dwBoxSize += sizeof(STSZBOX) - sizeof(STSZENTITY);
    DWORD dwEntityCount = 0;
    if(dwTrackID == VIDEO_STREAM_ID)
    {
        dwEntityCount = m_listVideoSampleTable.size();
        if(dwEntityCount > 0)
        {
            dwBoxSize += dwEntityCount * sizeof(STSZENTITY);
            lpStszBox->dwCount = LE_BE(dwEntityCount);
            std::list<PAYLOADINFO>::iterator it;
            for (it = m_listVideoSampleTable.begin();it != m_listVideoSampleTable.end();++it)
            {
                PAYLOADINFO payLoad = *it;
                DWORD size = payLoad.dwSize;
                lpStszEntity->dwSampleSize = LE_BE(size);
                lpStszEntity++;
            }
        }
    }
    else if(dwTrackID == AUDIO_STREAM_ID)
    {
        dwEntityCount = m_listAudioSampleTable.size();
        if(dwEntityCount > 0)
        {
            dwBoxSize += dwEntityCount * sizeof(STCOENTITY);
            lpStszBox->dwCount = LE_BE(dwEntityCount);
            std::list<PAYLOADINFO>::iterator it;
            for (it = m_listAudioSampleTable.begin();it != m_listAudioSampleTable.end();++it)
            {
                PAYLOADINFO payLoad = *it;
                lpStszEntity->dwSampleSize = LE_BE(payLoad.dwSize);
                lpStszEntity++;
            }
        }
    }
    lpStszBox->dwSize = LE_BE(dwBoxSize);
    return dwBoxSize;
}

DWORD CMp4Mux::WriteStcoBox(LPBYTE lpData,DWORD dwTrackID)
{
    DWORD dwBoxSize = 0;
    LPSTCOBOX lpStcoBox = (LPSTCOBOX)lpData;
    LPSTCOENTITY lpStcoEntity = &lpStcoBox->sEntity[0];
    lpStcoBox->dwName = ATOM_BOX_TYPE('s','t','c','o');
    dwBoxSize += sizeof(STCOBOX) - sizeof(STCOENTITY);
    DWORD dwEntityCount = 0;
    std::list<PAYLOADINFO>* sample = NULL;
    if(dwTrackID == VIDEO_STREAM_ID)
    {
        sample = &m_listVideoSampleTable;
    }
    else if(dwTrackID == AUDIO_STREAM_ID)
    {
        sample = &m_listAudioSampleTable;
    }
    dwEntityCount = sample->size();
    if(dwEntityCount > 0)
    {
        dwBoxSize += dwEntityCount * sizeof(STCOENTITY);
        lpStcoBox->dwCount = LE_BE(dwEntityCount);
        std::list<PAYLOADINFO>::iterator it;
        for (it = sample->begin();it != sample->end();++it)
        {
            PAYLOADINFO payLoad = *it;
            // Ĭ������£�m_dwMoovSize��ֵ�ǣ������ͣϣϣ���Ҫ�ƶ���ǰ���ʱ�����ǣͣϣϣֵĴ�С��
            lpStcoEntity->dwChunkAddr = LE_BE(payLoad.dwOffset + this->m_dwMoovSize);
            lpStcoEntity++;
        }
    }

    lpStcoBox->dwSize = LE_BE(dwBoxSize);
    return dwBoxSize;
}

DWORD CMp4Mux::LE_BE(DWORD dwValue)
{
    DWORD dwReturn ;
    dwReturn = (dwValue & 0xff) << 24 | (dwValue & 0xff00) << 8
                                   | (dwValue & 0xff0000) >> 8 | (dwValue & 0xff000000) >> 24;
    return dwReturn;
}

WORD CMp4Mux::LE_BE(WORD wValue)
{
    WORD wReturn;
    wReturn = (wValue & 0xff) << 8 | (wValue & 0xff00) >> 8;
    return wReturn;
}

INT64 CMp4Mux::LE_BE(INT64 nValue)
{
    INT64 nReturn;
    nReturn = (nValue & 0xff) << 56 | (nValue & 0xff00) << 40
                                 | (nValue & 0xff0000) << 24 | (nValue & 0xff000000) << 8
                                 | (nValue & 0xff00000000) >> 8 | (nValue & 0xff0000000000) >> 24
                                 | (nValue & 0xff000000000000) >> 40 | (nValue & 0xff00000000000000) >> 56;
    return nReturn;
}

BOOL CMp4Mux::GetBoxSize(LPBYTE lpData,DWORD& dwSize,DWORD& dwNalSize)
{
    if(lpData == NULL)
        return FALSE;
    DWORD dwTemp = 0;
    if(m_nNalSize == 4)
        dwTemp = lpData[0] << 24 | lpData[1] << 16 | lpData[2] << 8 | lpData[3];
    else if(m_nNalSize == 3)
        dwTemp = lpData[0] << 24 | lpData[1] << 16 | lpData[2] << 8;
    else if(m_nNalSize == 2)
        dwTemp = lpData[0] << 24 | lpData[1] << 16;
    else if(m_nNalSize == 1)
        dwTemp = lpData[0] << 24;
    dwSize = dwTemp;
    dwNalSize = m_nNalSize;
    return TRUE;
}

UINT CMp4Mux::CompuLen(UINT nLen)
{
    INT i;
    for(i = 1;nLen >> (7 * i);i++);
    return nLen + 1 + i;
}

UINT CMp4Mux::AddDes(LPBYTE lpData, INT nTag, UINT nSize)
{
    LPBYTE lpTemp = lpData;
    INT i = CompuLen(nSize) - nSize - 2;
    *lpTemp++ = nTag;
    for(;i > 0;i--)
        *lpTemp++ = (nSize >> (7 * i)) | 0x80;
    *lpTemp++ = nSize & 0x7F;
    return lpTemp - lpData;
}

INT CMp4Mux::GetSamplingFrequencyIndex(UINT nFrequency)
{
    switch (nFrequency) {
    case 96000: return 0;
    case 88200: return 1;
    case 64000: return 2;
    case 48000: return 3;
    case 44100: return 4;
    case 32000: return 5;
    case 24000: return 6;
    case 22050: return 7;
    case 16000: return 8;
    case 12000: return 9;
    case 11025: return 10;
    case 8000:  return 11;
    case 7350:  return 12;
    default:    return 0;
    }
}
INT CMp4Mux::GetSamplingFrequency(UINT idx)
{
    switch (idx) {
    case 0: return 96000;
    case 1: return 88200;
    case 2: return 64000;
    case 3: return 48000;
    case 4: return 44100;
    case 5: return 32000;
    case 6: return 24000;
    case 7: return 22050;
    case 8: return 16000;
    case 9: return 12000;
    case 10: return 11025;
    case 11: return 8000;
    case 12: return 7350;
    default:    return 0;
    }
}

void CMp4Mux::Init()
{
    m_writeMdatH = false;
    m_dwDataSize = 0;
    m_dwDataOffset = 0;
    m_dwFileWriteOffset = 0;

    m_bHasVideo =false;
    m_bHasAudio = false;

    m_nVideoIndex = 0;
    m_nAudioIndex = 0;
    m_dwCurrentTick = 0;

    m_dwMoovSize = 0;
    m_dwStreamCount = 0;

    m_dwTimeScale = 1000;
    m_dwDuration = 0;
    m_dwVideoDuration = 0;
    m_dwAudioDuration = 0;

    m_dwWidth = 0;
    m_dwHeight = 0;
    m_ratioX = 0;
    m_ratioY = 0;
    m_dbFrameRate = 25.0;
    m_nProfile = 0;
    m_nProfileCompatibility = 0;
    m_nLevel = 0;

    m_dwVideoDsiLen = 0;
    m_lpVideoDsiData = NULL;
    m_lpRecovryBuffer = NULL;
    m_vtimebase_den = 1.0;

    m_dwChannelCount = 2;
    m_dwBitsPerSample = 16;
    m_dwFrequency = 44100;
    m_dbFrequency = 15.625;
    memset(m_byAudioDsiData,0,2);
    m_atimebase_den = 1.0;

    m_dwVideoSampleCount = 0;
    m_dwAudioSampleCount = 0;
    m_listVideoSampleTable.clear();
    m_listAudioSampleTable.clear();

    m_pStream = NULL;
    m_bAudioFirst = true;
    m_bVideoFirst = true;
    m_llAudioFirst = 0;
    m_llAudioLast = 0;
    m_llVideoFirst = 0;
    m_llVideoLast = 0;
}
