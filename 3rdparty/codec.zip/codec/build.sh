#!/bin/sh

RED="\\e[31m"
GREEN="\\e[32m"
YELLOW="\\e[33m"
BLACK="\\e[0m"

current_dir=`pwd`

if ! test -d $current_dir/build; then
    mkdir $current_dir/build
fi

cd $current_dir/build
cmake .. -DCMAKE_BUILD_TYPE=Debug -DCMAKE_INSTALL_PREFIX=/usr/local
make

if test $? -ne 0;then
	echo -e $RED"build codec failed.........."$BLACK
else
	echo -e $GREEN"build codec success.........."$BLACK
fi

cd $current_dir

echo -e "custom build samples:\n\t\"mkdir build && cd build\""
echo -e "build release\t\"cmake .. -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=/usr/local\""
echo -e "build debug\t\"cmake .. -DCMAKE_BUILD_TYPE=Debug -DCMAKE_INSTALL_PREFIX=/usr/local\""

